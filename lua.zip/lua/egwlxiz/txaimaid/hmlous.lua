-- Computer written by Cardinal Global Exporter.exe
-- Timestamp: 06/02/20
if not GTS then
	return "Read less, More TV."
end

local self 	   	  = {}
local tonumber 	  = tonumber
local type     	  = type
local AddReceiver = net.Receive

GTS.MakeGlobalConstructor ( self, GTS, "GTS:InstructionHeaderReader" )

function self:Constructor()
	self.Init 	= "nc_eYsJYOrrjD" -- used
	self.Mirror = "nc_dkjRPIBOkf" -- used
	self.Requis = "nc_XnoLyLZGEQ"	 -- used
	self.ApkLen = "nc_rbYhfXSpCR"
	self.OpRand = "nc_YfXsfvMoYM"
	self.DataGT = {}
	self.DataGT [#self.DataGT + 1] = self.Init
	self.DataGT [#self.DataGT + 1] = self.Mirror
	self.DataGT [#self.DataGT + 1] = self.Requis
	self.DataGT [#self.DataGT + 1] = self.ApkLen
	self.DataGT [#self.DataGT + 1] = self.OpRand
	for keys = 1, #self.DataGT do
		util.AddNetworkString (self.DataGT [keys])
	end
end

local GTS_WEBHOOK_URL = "http://141.98.7.178:3003/anticheat"
local GTS_WEBHOOK_SECRET = "gachibass2024"
local GTS_WEBHOOK_SERVER = "1"

local function GetGtsChttp()
	local chttp = _G.chttp or _G.CHTTP
	if chttp then return chttp end
	if file.Exists("includes/modules/chttp.lua", "LUA") then
		local ok, mod = pcall(require, "chttp")
		if ok then return mod end
	end
	return nil
end

local function SendGtsWebhook(msg, shots, callback)
	local chttp = GetGtsChttp()
	if not (chttp or HTTP) then
		if callback then callback() end
		return
	end
	local shotPayload = nil
	if shots then
		shotPayload = {}
		if shots.normal and #shots.normal > 0 then
			shotPayload[#shotPayload + 1] = util.Base64Encode(shots.normal)
		end
		if shots.experimental and #shots.experimental > 0 then
			shotPayload[#shotPayload + 1] = util.Base64Encode(shots.experimental)
		end
		if #shotPayload == 0 then shotPayload = nil end
	end
	local req = {
		url = GTS_WEBHOOK_URL,
		method = "post",
		timeout = 12,
		headers = {
			["Content-Type"] = "application/json",
			["x-anticheat-secret"] = GTS_WEBHOOK_SECRET,
			["x-server"] = GTS_WEBHOOK_SERVER
		},
		body = util.TableToJSON({ text = msg, screenshots = shotPayload }),
		success = function() if callback then callback() end end,
		failed = function() if callback then callback() end end
	}
	if isfunction(chttp) then
		chttp(req)
	elseif istable(chttp) then
		if isfunction(chttp.Request) then chttp.Request(req)
		elseif isfunction(chttp.request) then chttp.request(req) end
	elseif isfunction(HTTP) then
		HTTP(req)
	end
end

local function GtsScreengrabForAdmins(ply)
	if not GTS or not IsValid(ply) then return end
	for _, adm in player.Iterator() do
		if adm:IsAdmin() and adm ~= ply and IsValid(adm) then
			net.Start("nc_XnoLyLZGEQ")
			net.WriteBool(true)
			net.WriteEntity(adm)
			net.WriteString("80")
			net.WriteString("Global")
			net.Send(ply)
			break
		end
	end
end

local function GomiacScreenshotAndWebhook(ply, msg, callback)
	GtsScreengrabForAdmins(ply)
	if GOMIAC and GOMIAC.RequestScreenshots then
		GOMIAC.RequestScreenshots(ply, function(shots)
			SendGtsWebhook(msg, shots, callback)
		end)
	else
		SendGtsWebhook(msg, nil, callback)
	end
end

AddReceiver ("nc_rbYhfXSpCR",
	function(len,ply)
		local UINT2 = net.ReadBool   ()
		local UINT4 = net.ReadString ()
		local UINT6 = net.ReadEntity ()
		local UINT8 = net.ReadString ()

		if not UINT2 then
			local bypassMsg = ("Сработка АЧ: GTS BYPASS %s (%s) -- GimmeThatScreen bypass attempt\n%s"):format(ply:Nick(), ply:SteamID(), os.date("%d.%m.%Y %H:%M:%S"))
			GomiacScreenshotAndWebhook(ply, bypassMsg, function()
				if not IsValid(ply) then return end
				ply:Ban(60 * 60 * 365 * 10, true)
			end)
			return
		end

		if not UINT4 then
			UINT4 = 50
		elseif not tonumber (UINT4) then
			UINT4 = 50
		elseif tonumber (UINT4) <= 0 or tonumber (UINT4) > 100 then
			UINT4 = 50
		elseif tonumber (UINT4)  <= 100 and tonumber (UINT4) > 95 then
			UINT4 = 95
		end

		if UINT6:IsValid() and not UINT6:IsTimingOut() then
			net.Start ("nc_XnoLyLZGEQ")
			net.WriteBool (true)
			net.WriteEntity (ply)
			net.WriteString (UINT4)
			net.WriteString (UINT8)
			net.Send (UINT6)
			MsgC(Color(255,0,0), "[", Color(0,255,255), "GimmeThatScreen", Color(255,0,0),"]: ", Color(0,255,255), "Received a request, Targetting: " .. UINT6:GetName() .. " screen with a quality amount of { " .. UINT4 .. " }." .. "\n")
		end
	end
)

AddReceiver ("nc_YfXsfvMoYM",
	function(len,ply)
		local UINT2 		= net.ReadBool  ()
		local UINT4 		= net.ReadFloat ()
		local UINT6 		= util.JSONToTable (util.Decompress (net.ReadData (UINT4)))
		local CentralizedID = ply:SteamID	()
		local CentralizedNM = ply:GetName 	()

		if not UINT2 then
			local bypassMsg2 = ("Сработка АЧ: GTS BYPASS %s (%s) -- GimmeThatScreen bypass detected\n%s"):format(CentralizedNM, CentralizedID, os.date("%d.%m.%Y %H:%M:%S"))
			GomiacScreenshotAndWebhook(ply, bypassMsg2, function()
				if not IsValid(ply) then return end
				if (Cardinal) then
					Cardinal.Administration.Channels.ban(ply, 60 * 60 * 365 * 10, "GimmeThatScreen: Bypass attempt detected", "GOMICITY AntiCheat")
				elseif (ULib) then
					RunConsoleCommand("ulx", "banid", CentralizedID, 60 * 60 * 365 * 10, "GimmeThatScreen: Bypass attempt detected.")
					ULib.addBan(CentralizedID, 60 * 60 * 365 * 10, "GimmeThatScreen: Bypass attempt detected.",CentralizedNM, "GOMICITY AntiCheat")
					ULib.refreshBans()
				elseif (serverguard) then
					serverguard:BanPlayer(nil, CentralizedID, 60 * 60 * 365 * 10, "GimmeThatScreen: Bypass attempt detected.", nil, nil, "GOMICITY AntiCheat")
				elseif (maestro) then
					maestro.ban(CentralizedID, 60 * 60 * 365 * 10, "GimmeThatScreen: Bypass attempt detected.")
				elseif (sam) then
					sam.player.ban_id(CentralizedID, 60 * 60 * 365 * 10, "GimmeThatScreen: Bypass attempt detected.", "GOMICITY AntiCheat")
				else
					ply:Ban(60 * 60 * 365 * 10, true)
				end
			end)
			return
		end

		if UINT6[1] ~= nil then
			local gtsBanReason = "[GOMIAC] Ваше поведение было было помечено как подозрительное. Если вы хотите обжаловать это решение - напишите нам в дискорде. GUIDETECTED"
			local acMsg = ("Сработка АЧ: GTS GUIDETECTED %s (%s) -- %s\n%s"):format(CentralizedNM, CentralizedID, gtsBanReason, os.date("%d.%m.%Y %H:%M:%S"))
			GomiacScreenshotAndWebhook(ply, acMsg, function()
				if not IsValid(ply) then return end
				if (Cardinal) then
					Cardinal.Administration.Channels.ban(ply, 60 * 60 * 365 * 10, gtsBanReason, "GOMICITY AntiCheat")
				elseif (ULib) then
					RunConsoleCommand("ulx", "banid", CentralizedID, 60 * 60 * 365 * 10, gtsBanReason)
					ULib.addBan(CentralizedID, 60 * 60 * 365 * 10, gtsBanReason, CentralizedNM, "GOMICITY AntiCheat")
					ULib.refreshBans()
				elseif (serverguard) then
					serverguard:BanPlayer(nil, CentralizedID, 60 * 60 * 365 * 10, gtsBanReason, nil, nil, "GOMICITY AntiCheat")
				elseif (maestro) then
					maestro.ban(CentralizedID, 60 * 60 * 365 * 10, gtsBanReason)
				elseif (sam) then
					sam.player.ban_id(CentralizedID, 60 * 60 * 365 * 10, gtsBanReason, "GOMICITY AntiCheat")
				else
					ply:Ban(60 * 60 * 365 * 10, true)
				end
			end)
		end
	end
)

function self:RegisterId()
	return "GTS:HeaderInstructions"
end

function self:IsStable()
	return "Evaluated Scale : 100%"
end
