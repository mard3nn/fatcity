if not SERVER then return end

hg = hg or {}
hg.DiscordLogs = hg.DiscordLogs or {}

local chttp = _G.chttp or _G.CHTTP

if not chttp and file.Exists("includes/modules/chttp.lua", "LUA") then
	local okCHTTP, chttpModule = pcall(require, "chttp")
	if okCHTTP then
		chttp = chttpModule or _G.chttp or _G.CHTTP
	else
		print("[ZC Discord] chttp not loaded: " .. tostring(chttpModule))
	end
end

if not chttp then
	print("[ZC Discord] chttp not found, falling back to HTTP.")
end

local logsCfgPath = "zcity_datacontent/discord_logs.json"
local defaultProxy = "http://141.98.7.178:3003/webhook-proxy"

-- ВАЖНО: на каждом сервере проекта `server_id` должен быть свой.
-- Он уходит боту в заголовке `x-server` и определяет:
--   * в какие каналы лягут логи и админ-логи,
--   * какие консольные команды из очереди адресованы этому серверу.
-- Меняется в консоли: zc_discord_server_set 2
local logsCfgDefaults = {
	enabled = true,
	server_id = "1",
	webhook_url = "",
	proxy_url = defaultProxy,
	command_enabled = true,
	command_poll_url = "http://141.98.7.178:3003/server-command/poll",
	command_ack_url = "http://141.98.7.178:3003/server-command/ack",
	command_secret = "mardenloh",
	username = "Навальный👋",
	avatar_url = ""
}

local function EnsureDataDir()
	if not file.IsDir("zcity_datacontent", "DATA") then
		file.CreateDir("zcity_datacontent")
	end
end

local function ReadLogsCfg()
	EnsureDataDir()

	if not file.Exists(logsCfgPath, "DATA") then
		local legacy = file.Read("gomigrad_datacontent/discord_logs.json", "DATA")
		if legacy then
			file.Write(logsCfgPath, legacy)
		else
			file.Write(logsCfgPath, util.TableToJSON(logsCfgDefaults, true))
			return table.Copy(logsCfgDefaults)
		end
	end

	local parsed = util.JSONToTable(file.Read(logsCfgPath, "DATA") or "")
	if not istable(parsed) then parsed = {} end

	for k, v in pairs(logsCfgDefaults) do
		if parsed[k] == nil then parsed[k] = v end
	end

	return parsed
end

local function SaveLogsCfg(cfg)
	EnsureDataDir()
	file.Write(logsCfgPath, util.TableToJSON(cfg or logsCfgDefaults, true))
end

local LogsCfg = ReadLogsCfg()
local cfgDirty = false

if LogsCfg.username == nil or LogsCfg.username == "" or LogsCfg.username == "Homigrad Logs" then
	LogsCfg.username = "Навальный👋"
	cfgDirty = true
end

if LogsCfg.proxy_url == nil or LogsCfg.proxy_url == "" then
	LogsCfg.proxy_url = defaultProxy
	cfgDirty = true
end

if LogsCfg.command_secret == nil or LogsCfg.command_secret == "" or LogsCfg.command_secret == "boglerishere" then
	LogsCfg.command_secret = logsCfgDefaults.command_secret
	cfgDirty = true
end

if LogsCfg.server_id == nil or tostring(LogsCfg.server_id) == "" then
	LogsCfg.server_id = logsCfgDefaults.server_id
	cfgDirty = true
end
LogsCfg.server_id = tostring(LogsCfg.server_id)

if cfgDirty then SaveLogsCfg(LogsCfg) end

local function GetServerId()
	local id = string.Trim(tostring(LogsCfg.server_id or ""))
	if id == "" then return logsCfgDefaults.server_id end
	return id
end

local function Sanitize(text)
	text = tostring(text or "")
	text = string.Replace(text, "@everyone", "@\226\128\139everyone")
	text = string.Replace(text, "@here", "@\226\128\139here")
	if #text > 1800 then text = string.sub(text, 1, 1800) .. "..." end
	return text
end

local function IsHttpOkCode(code)
	code = tonumber(code)
	return code and code >= 200 and code < 300
end

local queue = {}
local sending = false

local function GetTargetUrl()
	if LogsCfg.proxy_url and LogsCfg.proxy_url ~= "" then return LogsCfg.proxy_url, true end
	if LogsCfg.webhook_url and LogsCfg.webhook_url ~= "" then return LogsCfg.webhook_url, false end
	return nil, false
end

local function HasTarget()
	return GetTargetUrl() ~= nil
end

local function SendPayload(payload, onSuccess, onFail)
	local targetUrl = GetTargetUrl()
	if not targetUrl then onFail("no proxy or webhook configured") return end

	local req = {
		url = targetUrl,
		method = "post",
		timeout = 12,
		headers = {
			["Content-Type"] = "application/json",
			["x-server"] = GetServerId()
		},
		body = util.TableToJSON(payload),
		success = function(code, body, headers)
			if IsHttpOkCode(code) then onSuccess() return end
			onFail("HTTP code " .. tostring(code) .. " body: " .. tostring(body or ""))
		end,
		failed = function(err)
			onFail("HTTP failed: " .. tostring(err))
		end
	}

	if isfunction(chttp) then chttp(req) return end
	if istable(chttp) then
		if isfunction(chttp.Request) then chttp.Request(req) return end
		if isfunction(chttp.request) then chttp.request(req) return end
	end

	if isfunction(HTTP) then
		HTTP({
			url = req.url,
			method = req.method,
			body = req.body,
			timeout = req.timeout,
			type = "application/json",
			headers = req.headers,
			success = function(code, body, headers)
				req.success(code, body, headers)
			end,
			failed = function(err)
				req.failed(err)
			end
		})
		return
	end

	onFail("no http client available")
end

local commandPolling = false
local executedCommandIds = {}
local executedCommandOrder = {}

local function SendCommandRequest(url, payload, onSuccess, onFail)
	local secret = tostring(LogsCfg.command_secret or "")
	if secret == "" then onFail("command_secret is not configured") return end

	local req = {
		url = tostring(url or ""),
		method = "post",
		timeout = 10,
		headers = {
			["Content-Type"] = "application/json",
			["x-command-secret"] = secret,
			["x-server"] = GetServerId()
		},
		body = util.TableToJSON(payload or {}),
		success = function(code, body)
			if IsHttpOkCode(code) then onSuccess(body or "") return end
			onFail("HTTP code " .. tostring(code) .. " body: " .. tostring(body or ""))
		end,
		failed = function(err)
			onFail("HTTP failed: " .. tostring(err))
		end
	}

	if isfunction(chttp) then chttp(req) return end
	if istable(chttp) then
		if isfunction(chttp.Request) then chttp.Request(req) return end
		if isfunction(chttp.request) then chttp.request(req) return end
	end

	if isfunction(HTTP) then
		HTTP({
			url = req.url,
			method = req.method,
			body = req.body,
			timeout = req.timeout,
			type = "application/json",
			headers = req.headers,
			success = req.success,
			failed = req.failed
		})
		return
	end

	onFail("no http client available")
end

local function RememberExecutedCommand(id)
	if executedCommandIds[id] then return end
	executedCommandIds[id] = true
	executedCommandOrder[#executedCommandOrder + 1] = id

	while #executedCommandOrder > 200 do
		local oldId = table.remove(executedCommandOrder, 1)
		executedCommandIds[oldId] = nil
	end
end

local function AckRemoteCommand(id, ok, err, output)
	SendCommandRequest(LogsCfg.command_ack_url, {
		id = id,
		ok = ok and true or false,
		error = tostring(err or ""),
		output = tostring(output or "")
	}, function() end, function(ackErr)
		print("[ZC Discord Command] Ack failed: " .. tostring(ackErr))
	end)
end

local function FormatConnectedTime(seconds)
	seconds = math.max(0, math.floor(tonumber(seconds) or 0))
	local hours = math.floor(seconds / 3600)
	local minutes = math.floor((seconds % 3600) / 60)
	local secs = seconds % 60
	return string.format("%02d:%02d:%02d", hours, minutes, secs)
end

local function BuildStatusOutput()
	local players = player.GetAll()
	local humans = 0
	local bots = 0
	for _, ply in ipairs(players) do
		if ply:IsBot() then bots = bots + 1 else humans = humans + 1 end
	end

	local hostname = isfunction(GetHostName) and GetHostName() or "Garry's Mod server"
	local address = isfunction(game.GetIPAddress) and game.GetIPAddress() or "unknown"
	local lines = {
		"hostname: " .. tostring(hostname),
		"address:  " .. tostring(address),
		"map:      " .. tostring(game.GetMap()),
		string.format("players:  %d humans, %d bots (%d max)", humans, bots, game.MaxPlayers()),
		string.format("uptime:   %s", FormatConnectedTime(CurTime())),
		"",
		"#  userid  name                         steamid             connected  ping"
	}

	for index, ply in ipairs(players) do
		local name = string.gsub(tostring(ply:Nick()), "[%c]", " ")
		if #name > 28 then name = string.sub(name, 1, 25) .. "..." end
		lines[#lines + 1] = string.format(
			"%-2d %-7s %-28s %-19s %-9s %d",
			index,
			tostring(ply:UserID()),
			name,
			tostring(ply:SteamID()),
			FormatConnectedTime(ply:TimeConnected()),
			tonumber(ply:Ping()) or 0
		)
	end

	return string.sub(table.concat(lines, "\n"), 1, 12000)
end

-- Локальный накопительный реестр кандидатов. На каждом сервере хранится отдельно,
-- бот складывает время с серверов и объединяет историю банов.
local dossierPath = "zcity_datacontent/player_dossier.json"
local dossier = util.JSONToTable(file.Read(dossierPath, "DATA") or "") or {}

local function DossierSteamID(value)
	local raw = string.upper(string.Trim(tostring(value or "")))
	if string.match(raw, "^STEAM_%d:[01]:%d+$") then return raw end
	if string.match(raw, "^765%d%d%d%d%d%d%d%d%d%d%d%d%d%d$") and util.SteamIDFrom64 then
		return string.upper(tostring(util.SteamIDFrom64(raw) or ""))
	end
	return ""
end

local function DossierEntry(steamID)
	dossier[steamID] = dossier[steamID] or {
		steam_id = steamID,
		seconds = 0,
		bans = {}
	}
	return dossier[steamID]
end

local function SaveDossier()
	EnsureDataDir()
	file.Write(dossierPath, util.TableToJSON(dossier, true))
end

local function UpdateDossierPlayer(ply, seconds)
	if not IsValid(ply) or not ply:IsPlayer() or ply:IsBot() then return end
	local steamID = DossierSteamID(ply:SteamID())
	if steamID == "" then return end
	local entry = DossierEntry(steamID)
	entry.steam_id64 = tostring(ply:SteamID64() or entry.steam_id64 or "")
	entry.name = tostring(ply:Nick() or entry.name or "")
	entry.seconds = math.max(0, tonumber(entry.seconds) or 0) + math.max(0, tonumber(seconds) or 0)
	entry.karma = tonumber(ply.Karma) or entry.karma
	entry.group = tostring(ply:GetUserGroup() or entry.group or "user")
	entry.last_seen = os.time()
end

local function RecordDossierBan(steamID, duration, reason, moderator)
	steamID = DossierSteamID(steamID)
	if steamID == "" then return end
	local entry = DossierEntry(steamID)
	entry.bans = istable(entry.bans) and entry.bans or {}
	entry.bans[#entry.bans + 1] = {
		at = os.time(),
		duration = tostring(duration or ""),
		reason = tostring(reason or "Причина не указана"),
		moderator = tostring(moderator or "Console")
	}
	while #entry.bans > 50 do table.remove(entry.bans, 1) end
	SaveDossier()
end

timer.Create("ZC_Dossier_Track", 60, 0, function()
	for _, ply in ipairs(player.GetHumans()) do UpdateDossierPlayer(ply, 60) end
	SaveDossier()
end)

hook.Add("PlayerInitialSpawn", "ZC_Dossier_Seen", function(ply)
	timer.Simple(5, function()
		if IsValid(ply) then
			UpdateDossierPlayer(ply, 0)
			SaveDossier()
		end
	end)
end)

hook.Add("ShutDown", "ZC_Dossier_Save", function()
	for _, ply in ipairs(player.GetHumans()) do UpdateDossierPlayer(ply, 0) end
	SaveDossier()
end)

local function BuildDossierOutput(rawSteamID)
	local steamID = DossierSteamID(rawSteamID)
	if steamID == "" then return nil, "invalid SteamID" end
	local entry = table.Copy(dossier[steamID] or { steam_id = steamID, seconds = 0, bans = {} })
	entry.server_id = GetServerId()
	entry.active_ban = nil
	if ULib and istable(ULib.bans) and istable(ULib.bans[steamID]) then
		local ban = ULib.bans[steamID]
		entry.active_ban = {
			reason = tostring(ban.reason or ""),
			unban = tonumber(ban.unban) or 0,
			admin = tostring(ban.admin or "")
		}
	end
	return util.TableToJSON(entry), nil
end

-- Команды из очереди бота выполняются через game.ConsoleCommand, то есть асинхронно.
-- В этом окне ULX-действия помечаются origin = "discord", чтобы бот не зеркалил их
-- обратно на сервер-источник и не устроил бесконечный круг синхронизации.
local remoteExecUntil = -1

local function IsRemoteExecuting()
	return CurTime() <= remoteExecUntil
end

local function ExecuteRemoteCommand(item)
	local id = string.Trim(tostring(item and item.id or ""))
	local command = string.Trim(tostring(item and item.command or ""))
	if id == "" then return end

	if executedCommandIds[id] then
		AckRemoteCommand(id, true, "duplicate ignored")
		return
	end

	if command == "" or #command > 500 or string.find(command, "[\r\n%z]") then
		AckRemoteCommand(id, false, "invalid command")
		return
	end

	RememberExecutedCommand(id)
	print(string.format("[ZC Discord Command] %s -> %s", tostring(item.requestedBy or "unknown"), command))
	if string.lower(command) == "status" then
		AckRemoteCommand(id, true, "", BuildStatusOutput())
		return
	end
	local dossierTarget = string.match(command, "^zc_dossier%s+(%S+)$")
	if dossierTarget then
		local output, dossierError = BuildDossierOutput(dossierTarget)
		AckRemoteCommand(id, output ~= nil, dossierError or "", output or "")
		return
	end

	remoteExecUntil = CurTime() + 2
	local ok, err = pcall(game.ConsoleCommand, command .. "\n")
	AckRemoteCommand(id, ok, ok and "" or tostring(err), "")
end

local function PollRemoteCommands()
	if commandPolling or not LogsCfg.command_enabled then return end
	if tostring(LogsCfg.command_secret or "") == "" then return end
	if tostring(LogsCfg.command_poll_url or "") == "" then return end

	commandPolling = true
	SendCommandRequest(LogsCfg.command_poll_url, {}, function(body)
		commandPolling = false
		local response = util.JSONToTable(body or "")
		if not istable(response) or not istable(response.commands) then return end
		for _, item in ipairs(response.commands) do ExecuteRemoteCommand(item) end
	end, function(err)
		commandPolling = false
		print("[ZC Discord Command] Poll failed: " .. tostring(err))
	end)
end

timer.Create("ZC_DiscordCommand_Poll", 2, 0, PollRemoteCommands)

local function PumpQueue()
	if sending then return end
	if #queue <= 0 then return end
	if not LogsCfg.enabled or not HasTarget() then return end

	sending = true
	local payload = table.remove(queue, 1)

	SendPayload(payload, function()
		sending = false
		timer.Simple(0.6, PumpQueue)
	end, function(err)
		sending = false
		print("[ZC Discord] Send failed: " .. tostring(err))
		timer.Simple(1.2, PumpQueue)
	end)
end

local COLORS = {
	join    = 0x57F287,
	leave   = 0xED4245,
	weapon  = 0x5865F2,
	noclip  = 0xFEE75C,
	prop    = 0xEB459E,
	npc     = 0xE67E22,
	entity  = 0x1ABC9C,
	pick    = 0x3498DB,
	admin   = 0x95A5A6,
	round   = 0xFFFFFF,
	info    = 0xAFB8C1
}

hg.DiscordLogs.Colors = COLORS

function hg.DiscordLogs.Send(title, description, color)
	if not LogsCfg.enabled or not HasTarget() then return end

	local embed = {
		title = Sanitize(title),
		description = Sanitize(description),
		color = tonumber(color) or COLORS.info,
		footer = { text = os.date("%H:%M:%S МСК", os.time() + 3 * 3600) }
	}

	queue[#queue + 1] = {
		username = LogsCfg.username ~= "" and LogsCfg.username or "Навальный👋",
		avatar_url = LogsCfg.avatar_url ~= "" and LogsCfg.avatar_url or nil,
		embeds = { embed }
	}

	PumpQueue()
end

local function PlayerLogIdentity(ply, fallbackName)
	if not IsValid(ply) or not ply:IsPlayer() then
		return { name = tostring(fallbackName or "Console"), steam_id = "", steam_id64 = "" }
	end

	return {
		name = tostring(ply:Nick() or fallbackName or "unknown"),
		steam_id = tostring(ply:SteamID() or ""),
		steam_id64 = tostring(ply:SteamID64() or "")
	}
end

local function FindAdminLogTarget(rawTarget)
	if IsValid(rawTarget) and rawTarget:IsPlayer() then return rawTarget end
	if istable(rawTarget) then
		for _, ply in pairs(rawTarget) do
			if IsValid(ply) and ply:IsPlayer() then return ply end
		end
	end

	local query = string.Trim(tostring(rawTarget or ""))
	query = string.gsub(query, '^"(.*)"$', '%1')
	if query == "" then return nil end

	for _, ply in ipairs(player.GetAll()) do
		if ply:SteamID() == query or ply:SteamID64() == query or string.lower(ply:Nick()) == string.lower(query) then
			return ply
		end
	end

	local lowerQuery = string.lower(query)
	local matched = nil
	for _, ply in ipairs(player.GetAll()) do
		if string.find(string.lower(ply:Nick()), lowerQuery, 1, true) then
			if matched then return nil end
			matched = ply
		end
	end

	return matched
end

local function TargetLogIdentity(rawTarget)
	local targetPly = FindAdminLogTarget(rawTarget)
	if IsValid(targetPly) then return PlayerLogIdentity(targetPly) end

	local raw = string.Trim(tostring(rawTarget or "неизвестно"))
	local steamID64 = ""
	if string.match(raw, "^765%d%d%d%d%d%d%d%d%d%d%d%d%d%d$") then
		steamID64 = raw
	elseif string.match(string.upper(raw), "^STEAM_%d:[01]:%d+$") and util.SteamIDTo64 then
		steamID64 = tostring(util.SteamIDTo64(raw) or "")
	end

	return { name = raw, steam_id = raw, steam_id64 = steamID64 }
end

local function JoinAdminArgs(args, firstIndex)
	if not istable(args) then return "" end
	local values = {}
	for i = firstIndex, #args do
		local value = string.Trim(tostring(args[i] or ""))
		if value ~= "" then values[#values + 1] = value end
	end
	return table.concat(values, " ")
end

local function LooksLikeDuration(value)
	value = string.lower(string.Trim(tostring(value or "")))
	if value == "" then return false end
	if tonumber(value) ~= nil then return true end
	if string.match(value, "^%d+[%s]*[smhdw]+$") then return true end
	if value == "perma" or value == "permanent" or value == "навсегда" then return true end
	return string.match(value, "^%d+[%s]*сек$") ~= nil or
		string.match(value, "^%d+[%s]*мин$") ~= nil or
		string.match(value, "^%d+[%s]*час$") ~= nil or
		string.match(value, "^%d+[%s]*дн$") ~= nil
end

function hg.DiscordLogs.SendAdminAction(action, callingPly, args, command, extra)
	if not LogsCfg.enabled or not HasTarget() then return end

	args = istable(args) and args or {}
	local targetRaw = args[1] or "неизвестно"
	local duration = ""
	local group = ""
	local reasonStart = 2

	if action == "ban" then
		duration = tostring(args[2] or "")
		reasonStart = 3
	elseif (action == "mute" or action == "gag") and LooksLikeDuration(args[2]) then
		duration = tostring(args[2])
		reasonStart = 3
	elseif action == "group_add" then
		-- ulx adduserid <steamid> <группа>
		group = tostring(args[2] or "")
		reasonStart = 3
	end

	local reason = JoinAdminArgs(args, reasonStart)
	if reason == "" then reason = "Причина не указана" end

	queue[#queue + 1] = {
		type = "admin_action",
		admin_log = {
			action = tostring(action),
			command = tostring(command or ""),
			target = TargetLogIdentity(targetRaw),
			moderator = PlayerLogIdentity(callingPly),
			duration = duration,
			group = group,
			reason = reason,
			server = GetHostName and GetHostName() or "GOMIGRAD",
			server_id = GetServerId(),
			-- "discord" = действие пришло командой от бота, зеркалить не нужно
			origin = IsRemoteExecuting() and "discord" or "game",
			map = game.GetMap(),
			timestamp = os.time()
		}
	}

	if istable(extra) then
		for key, value in pairs(extra) do
			queue[#queue].admin_log[key] = value
		end
	end

	PumpQueue()
end

-- ULibCommandCalled срабатывает и для команд, которым позже будет отказано в доступе.
-- Поэтому бан нельзя синхронизировать по одному факту вызова команды: ждём следующий
-- тик и убеждаемся, что запись в ULib.bans действительно появилась или изменилась.
local function ResolveBanSteamID(rawTarget)
	local targetPly = FindAdminLogTarget(rawTarget)
	if IsValid(targetPly) then return string.upper(tostring(targetPly:SteamID() or "")) end

	local raw = string.upper(string.Trim(tostring(rawTarget or "")))
	if string.match(raw, "^STEAM_%d:[01]:%d+$") then return raw end
	if string.match(raw, "^765%d%d%d%d%d%d%d%d%d%d%d%d%d%d$") and util.SteamIDFrom64 then
		return string.upper(tostring(util.SteamIDFrom64(raw) or ""))
	end
	return ""
end

local function BanSignature(steamID)
	if steamID == "" or not ULib or not istable(ULib.bans) then return nil end
	local ban = ULib.bans[steamID]
	if not istable(ban) then return nil end
	return table.concat({
		tostring(ban.time or ""),
		tostring(ban.unban or ""),
		tostring(ban.reason or ""),
		tostring(ban.admin or "")
	}, "\31")
end

function hg.DiscordLogs.SetWebhook(url)
	LogsCfg.webhook_url = tostring(url or "")
	SaveLogsCfg(LogsCfg)
end

function hg.DiscordLogs.SetProxy(url)
	LogsCfg.proxy_url = tostring(url or "")
	SaveLogsCfg(LogsCfg)
	print("[ZC Discord] Proxy set to: " .. (LogsCfg.proxy_url ~= "" and LogsCfg.proxy_url or "disabled, falling back to webhook"))
end

function hg.DiscordLogs.SetServerId(id)
	id = string.Trim(tostring(id or ""))
	if id == "" then
		print("[ZC Discord] server_id cannot be empty.")
		return
	end

	LogsCfg.server_id = id
	SaveLogsCfg(LogsCfg)
	print("[ZC Discord] server_id set to: " .. id .. " (должен совпадать с id в config.js бота)")
end

function hg.DiscordLogs.Enable(state)
	LogsCfg.enabled = state and true or false
	SaveLogsCfg(LogsCfg)
end

function DiscordLog(message, logType, color)
	hg.DiscordLogs.Send("Log", tostring(message or ""), color or COLORS.info)
end

local function SafePlyName(ply)
	if not IsValid(ply) then return "Console" end
	if not ply:IsPlayer() then return tostring(ply:GetClass() or "entity") end
	return string.format("%s (%s)", ply:Nick(), ply:SteamID())
end

local function GetRoundMode()
	if not zb then return "unknown" end

	if isfunction(CurrentRound) then
		local ok, mode, round = pcall(CurrentRound)
		if ok and istable(mode) then
			return tostring(mode.name or round or zb.CROUND or "unknown")
		end
	end

	return tostring(zb.CROUND_MAIN or zb.CROUND or "unknown")
end

local function GetRoundNumber()
	return tonumber(zb and zb.Roundscount or 0) or 0
end

local function IsRoundActive()
	return zb and zb.ROUND_STATE == 1
end

local function IsHomicide()
	return string.lower(GetRoundMode()) == "hmcd"
end

local function IsTraitor(ply)
	if not IsValid(ply) or not ply:IsPlayer() then return false end
	return ply.isTraitor == true
end

local traitorSnapshot = {}

local function RefreshTraitorSnapshot()
	if not IsHomicide() then return end

	for _, ply in ipairs(player.GetAll()) do
		if IsTraitor(ply) then
			traitorSnapshot[ply:SteamID()] = ply:Nick() .. (ply.MainTraitor and " (главный)" or "")
		end
	end
end

local function CollectTraitors()
	if not IsHomicide() then return nil end

	RefreshTraitorSnapshot()

	local traitors = {}
	for _, name in pairs(traitorSnapshot) do
		traitors[#traitors + 1] = name
	end

	if #traitors == 0 then return "нет данных" end
	table.sort(traitors)
	return table.concat(traitors, ", ")
end

timer.Create("ZC_DiscordLogs_TraitorSnapshot", 2, 0, function()
	if not IsRoundActive() then return end
	RefreshTraitorSnapshot()
end)

local roundKills = {}
local lastRoundSummaryKey = nil
local lastWeapons = {}

local function ResetRoundKills()
	roundKills = {}
	lastWeapons = {}
	traitorSnapshot = {}
end

function hg.DiscordLogs.SendRoundSummary(force)
	local curRound = GetRoundNumber()
	local curName = GetRoundMode()
	local summaryKey = string.format("%s:%s:%s", tostring(curRound), curName, tostring(game.GetMap()))

	if not force and lastRoundSummaryKey == summaryKey then return end

	local traitors = CollectTraitors()
	if traitors then
		hg.DiscordLogs.Send("Конец раунда", string.format("Режим: %s\nПредатели: %s", curName, traitors), COLORS.round)
	else
		hg.DiscordLogs.Send("Конец раунда", "Режим: " .. curName, COLORS.round)
	end

	hg.DiscordLogs.Send("Убийства", #roundKills > 0 and table.concat(roundKills, "\n") or "no kills", COLORS.round)
	lastRoundSummaryKey = summaryKey
end

local function ResolveKillAttacker(victim)
	if not IsValid(victim) then return NULL end

	local best, bestHarm = NULL, 0
	local harmTable = zb and zb.HarmDone and zb.HarmDone[victim]

	if istable(harmTable) then
		for attacker, harm in pairs(harmTable) do
			harm = tonumber(harm) or 0
			if IsValid(attacker) and attacker:IsPlayer() and harm > bestHarm then
				best, bestHarm = attacker, harm
			end
		end
	end

	if IsValid(best) then return best end

	local physAttacker = victim.GetPhysicsAttacker and victim:GetPhysicsAttacker() or nil
	if IsValid(physAttacker) and physAttacker:IsPlayer() then return physAttacker end

	return NULL
end

local function GetKillWeaponClass(victim, attacker)
	local victimWeapons = IsValid(victim) and lastWeapons[victim:SteamID()] or nil
	if istable(victimWeapons) and IsValid(attacker) then
		local stored = victimWeapons[attacker:SteamID()]
		if stored and stored ~= "" then return stored end
	end

	if IsValid(attacker) and attacker:IsPlayer() then
		local wep = attacker:GetActiveWeapon()
		if IsValid(wep) then
			return tostring(wep:GetClass() or "unknown")
		end
	end

	return "unknown"
end

hook.Add("HomigradDamage", "ZC_DiscordLogs_TrackWeapon", function(victim, dmgInfo, hitgroup, ent, harm)
	if not IsValid(victim) or not victim:IsPlayer() then return end
	if not dmgInfo or not dmgInfo.GetAttacker then return end

	local attacker = dmgInfo:GetAttacker()
	if not IsValid(attacker) or not attacker:IsPlayer() or attacker == victim then return end

	local class = "unknown"
	local inflictor = dmgInfo.GetInflictor and dmgInfo:GetInflictor() or nil

	if IsValid(inflictor) and inflictor ~= attacker then
		class = tostring(inflictor:GetClass() or "unknown")
	else
		local wep = attacker:GetActiveWeapon()
		if IsValid(wep) then class = tostring(wep:GetClass() or "unknown") end
	end

	local vid = victim:SteamID()
	lastWeapons[vid] = lastWeapons[vid] or {}
	lastWeapons[vid][attacker:SteamID()] = class
end)

local function GetKillTraitorSuffix(attacker)
	if not IsHomicide() then return "" end
	if not IsValid(attacker) or not attacker:IsPlayer() then return "" end
	if IsTraitor(attacker) then return " (убийца = не предатель)" end
	return " (убийца = не предатель)"
end

local function RegisterKill(victim)
	if not IsValid(victim) or not victim:IsPlayer() then return end

	local victimName = tostring(victim:Nick() or "unknown")
	local victimTraitor = IsHomicide() and IsTraitor(victim)
	local realAttacker = ResolveKillAttacker(victim)

	if not IsValid(realAttacker) or realAttacker == victim then
		roundKills[#roundKills + 1] = string.format(
			"%s — смерть без убийцы%s",
			victimName,
			victimTraitor and " (был предателем)" or ""
		)
		return
	end

	roundKills[#roundKills + 1] = string.format(
		"%s (%s) %s%s%s",
		tostring(realAttacker:Nick() or "unknown"),
		GetKillWeaponClass(victim, realAttacker),
		victimName,
		victimTraitor and " (жертва = предатель)" or "",
		GetKillTraitorSuffix(realAttacker)
	)
end

hook.Add("Player_Death", "ZC_DiscordLogs_RoundKills", function(victim)
	if not IsRoundActive() then return end
	if not IsValid(victim) or not victim:IsPlayer() then return end

	RefreshTraitorSnapshot()

	local traitorFlag = IsTraitor(victim)
	local name = tostring(victim:Nick() or "unknown")

	timer.Simple(0.15, function()
		if not IsValid(victim) then
			roundKills[#roundKills + 1] = name .. " — смерть" .. (traitorFlag and " (был предателем)" or "")
			return
		end
		RegisterKill(victim)
	end)
end)

hook.Add("ZB_StartRound", "ZC_DiscordLogs_RoundStart", function()
	ResetRoundKills()
	lastRoundSummaryKey = nil

	timer.Simple(1, RefreshTraitorSnapshot)
	timer.Simple(5, RefreshTraitorSnapshot)
	hg.DiscordLogs.Send("Начало раунда", string.format("#%d - %s", GetRoundNumber() + 1, GetRoundMode()), COLORS.round)
end)

hook.Add("ZB_EndRound", "ZC_DiscordLogs_RoundEnd", function()
	timer.Simple(0, function()
		hg.DiscordLogs.SendRoundSummary()
	end)
end)

hook.Add("ZB_TraitorWinOrNot", "ZC_DiscordLogs_TraitorResult", function(traitor, winner)
	if IsValid(traitor) and traitor:IsPlayer() then
		traitorSnapshot[traitor:SteamID()] = traitor:Nick() .. (traitor.MainTraitor and " (главный)" or "")
	end

	local name = IsValid(traitor) and traitor:Nick() or "unknown"
	hg.DiscordLogs.Send("Итог предателя", string.format("%s: %s", name, winner and "победа" or "проигрыш"), COLORS.round)
end)

hook.Add("PostGamemodeLoaded", "ZC_DiscordLogs_MapLoad", function()
	hg.DiscordLogs.Send("Смена карты", "Карта: `" .. game.GetMap() .. "`", COLORS.round)
end)

hook.Add("PlayerInitialSpawn", "ZC_DiscordLogs_Join", function(ply)
	hg.DiscordLogs.Send("Подключился", SafePlyName(ply), COLORS.join)
end)

hook.Add("PlayerDisconnected", "ZC_DiscordLogs_Leave", function(ply)
	hg.DiscordLogs.Send("Отключился", SafePlyName(ply), COLORS.leave)
end)

local adminChatCommands = {
	["forcertv"] = "Принудительный RTV",
	["rtv"] = "RTV",
	["setmode"] = "Смена режима",
	["nextmode"] = "Следующий режим",
	["restartround"] = "Рестарт раунда",
	["skip"] = "Скип раунда",
	["slay"] = "Слей",
	["respawn"] = "Респавн",
	["god"] = "God режим",
	["give"] = "Выдача предмета",
	["traitor"] = "Выдача предателя",
	["giverole"] = "Выдача роли"
}

hook.Add("PlayerSay", "ZC_DiscordLogs_Chat", function(ply, text)
	if not LogsCfg.enabled then return end
	if not IsValid(ply) then return end

	text = tostring(text or "")
	if text == "" then return end

	local first = string.sub(text, 1, 1)
	if first == "!" or first == "/" or first == "." or first == "*" then
		local body = string.sub(text, 2)
		local cmd = string.lower(string.match(body, "^(%S+)") or "")
		local label = adminChatCommands[cmd]
		if label then
			local args = string.Trim(string.sub(body, #cmd + 1))
			hg.DiscordLogs.Send(
				label,
				string.format("%s → %s", SafePlyName(ply), args ~= "" and args or "без аргументов"),
				COLORS.admin
			)
		end
		return
	end

	hg.DiscordLogs.Send("Чат", string.format("%s: %s", SafePlyName(ply), text), COLORS.info)
end)

hook.Add("PlayerGiveSWEP", "ZC_DiscordLogs_GiveSWEP", function(ply, class)
	hg.DiscordLogs.Send("Выдача оружия", string.format("%s\n`%s`", SafePlyName(ply), tostring(class)), COLORS.weapon)
end)

hook.Add("PlayerNoClip", "ZC_DiscordLogs_NoClip", function(ply, state)
	hg.DiscordLogs.Send(state and "Ноуклип включён" or "Ноуклип выключен", SafePlyName(ply), COLORS.noclip)
end)

hook.Add("PlayerSpawnedProp", "ZC_DiscordLogs_Prop", function(ply, model, ent)
	hg.DiscordLogs.Send("Спавн пропа", string.format("%s\n`%s`", SafePlyName(ply), tostring(model)), COLORS.prop)
end)

hook.Add("PlayerSpawnedNPC", "ZC_DiscordLogs_NPC", function(ply, ent)
	local class = IsValid(ent) and ent:GetClass() or "unknown"
	hg.DiscordLogs.Send("Спавн НПС", string.format("%s\n`%s`", SafePlyName(ply), class), COLORS.npc)
end)

hook.Add("PlayerSpawnedSENT", "ZC_DiscordLogs_SENT", function(ply, ent)
	local class = IsValid(ent) and ent:GetClass() or "unknown"
	hg.DiscordLogs.Send("Спавн энтити", string.format("%s\n`%s`", SafePlyName(ply), class), COLORS.entity)
end)

hook.Add("GravGunOnPickedUp", "ZC_DiscordLogs_GravPick", function(ply, ent)
	if not IsValid(ent) then return end
	hg.DiscordLogs.Send("Поднял", string.format("%s\n`%s`", SafePlyName(ply), ent:GetClass()), COLORS.pick)
end)

hook.Add("PhysgunPickup", "ZC_DiscordLogs_PhysPick", function(ply, ent)
	if not IsValid(ent) then return end
	hg.DiscordLogs.Send("Поднял", string.format("%s\n`%s`", SafePlyName(ply), ent:GetClass()), COLORS.pick)
end)

hook.Add("ULibCommandCalled", "ZC_DiscordLogs_ULX", function(calling_ply, command, args)
	local cmd = string.lower(tostring(command or ""))
	if cmd == "" then return end
	if string.find(cmd, "thetime", 1, true) then return end
	if not string.StartWith(cmd, "ulx ") then return end
	if cmd == "ulx help" or cmd == "ulx version" then return end

	local adminActions = {
		["ulx mute"]         = "mute",
		["ulx unmute"]       = "unmute",
		["ulx gag"]          = "gag",
		["ulx ungag"]        = "ungag",
		["ulx pgag"]         = "gag",
		["ulx unpgag"]       = "ungag",
		["ulx ban"]          = "ban",
		["ulx sban"]         = "ban",
		["ulx banid"]        = "ban",
		["ulx banip"]        = "ban",
		["ulx unban"]        = "unban",
		["ulx unbanid"]      = "unban",
		["ulx kick"]         = "kick",
		["ulx votekick"]     = "kick",
		-- Роли (ULX-группы): бот зеркалит их на остальные серверы проекта
		["ulx adduser"]      = "group_add",
		["ulx adduserid"]    = "group_add",
		["ulx removeuser"]   = "group_remove",
		["ulx removeuserid"] = "group_remove"
	}

	if adminActions[cmd] then
		local action = adminActions[cmd]
		if action == "ban" then
			local steamID = ResolveBanSteamID(istable(args) and args[1] or "")
			local before = BanSignature(steamID)
			local savedArgs = table.Copy(istable(args) and args or {})
			if steamID ~= "" then savedArgs[1] = steamID end

			timer.Simple(0, function()
				local after = BanSignature(steamID)
				local verified = after ~= nil and after ~= before
				if verified then
					RecordDossierBan(
						steamID,
						savedArgs[2],
						JoinAdminArgs(savedArgs, 3),
						SafePlyName(calling_ply)
					)
				end
				hg.DiscordLogs.SendAdminAction(action, calling_ply, savedArgs, command, {
					ban_verified = verified
				})
			end)
		else
			hg.DiscordLogs.SendAdminAction(action, calling_ply, args, command)
		end
		return
	end

	local tracked = {
		["ulx respawn"]      = "Респавн",
		["ulx forcerespawn"] = "Респавн",
		["ulx god"]          = "God режим",
		["ulx ungod"]        = "God режим снят",
		["ulx give"]         = "Выдача предмета",
		["ulx vote"]         = "Голосование",
		["ulx votemode"]     = "Голосование за режим",
		["ulx votemap"]      = "Голосование",
		["ulx votemap2"]     = "Голосование",
		["ulx ignite"]       = "Ignite",
		["ulx unignite"]     = "Extinguish",
		["ulx unigniteall"]  = "Extinguish all",
		["ulx rtv"]          = "RTV",
		-- Правки прав и групп: не зеркалим автоматически, но логируем
		["ulx userallow"]    = "Выдача права",
		["ulx userdeny"]     = "Снятие права",
		["ulx groupallow"]   = "Право группе",
		["ulx groupdeny"]    = "Право снято у группы",
		["ulx addgroup"]     = "Создана группа",
		["ulx removegroup"]  = "Удалена группа",
		["ulx renamegroup"]  = "Группа переименована",
		["ulx setgroupcantarget"] = "Настройка таргета группы"
	}

	local label = tracked[cmd] or tostring(command)

	local argText = ""
	if istable(args) and #args > 0 then
		for i = 1, math.min(#args, 4) do
			argText = argText .. tostring(args[i]) .. (i < math.min(#args, 4) and ", " or "")
		end
	end

	hg.DiscordLogs.Send(
		label,
		string.format("%s → %s", SafePlyName(calling_ply), argText ~= "" and argText or "без аргументов"),
		COLORS.admin
	)
end)

hook.Add("PostGamemodeLoaded", "ZC_DiscordLogs_HookRTV", function()
	if not zb then return end

	if isfunction(zb.StartRTV) and not zb.DiscordLogsRTVWrapped then
		zb.DiscordLogsRTVWrapped = true
		local originalStartRTV = zb.StartRTV
		zb.StartRTV = function(...)
			if not zb.votestarted then
				hg.DiscordLogs.Send("RTV", "Голосование за смену карты запущено", COLORS.admin)
			end
			return originalStartRTV(...)
		end
	end

	if isfunction(zb.EndRTV) and not zb.DiscordLogsEndRTVWrapped then
		zb.DiscordLogsEndRTVWrapped = true
		local originalEndRTV = zb.EndRTV
		zb.EndRTV = function(...)
			hg.DiscordLogs.Send("RTV", "Голосование за смену карты завершено", COLORS.admin)
			return originalEndRTV(...)
		end
	end
end)

concommand.Add("zc_discord_webhook_set", function(ply, _, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	hg.DiscordLogs.SetWebhook(tostring(args[1] or ""))
	print("[ZC Discord] Webhook updated.")
end)

concommand.Add("zc_discord_proxy_set", function(ply, _, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	hg.DiscordLogs.SetProxy(table.concat(args, " "))
end)

concommand.Add("zc_discord_server_set", function(ply, _, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	hg.DiscordLogs.SetServerId(args[1])
end)

concommand.Add("zc_discord_logs_enable", function(ply, _, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	local state = tonumber(args[1] or 1) == 1
	hg.DiscordLogs.Enable(state)
	print("[ZC Discord] Logs " .. (state and "enabled" or "disabled") .. ".")
end)

concommand.Add("zc_discord_status", function(ply)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	print("[ZC Discord] enabled=" .. tostring(LogsCfg.enabled))
	print("[ZC Discord] server_id=" .. GetServerId())
	print("[ZC Discord] webhook_url=" .. tostring(LogsCfg.webhook_url or ""))
	print("[ZC Discord] proxy_url=" .. tostring(LogsCfg.proxy_url or ""))
	print("[ZC Discord] target=" .. tostring(GetTargetUrl() or "none"))
	print("[ZC Discord] queued=" .. tostring(#queue))
	print("[ZC Discord] round=" .. GetRoundMode() .. " state=" .. tostring(zb and zb.ROUND_STATE))
	print("[ZC Discord] kills=" .. tostring(#roundKills) .. " traitors=" .. tostring(table.Count(traitorSnapshot)))
	print("[ZC Discord] command_enabled=" .. tostring(LogsCfg.command_enabled))
	print("[ZC Discord] command_poll_url=" .. tostring(LogsCfg.command_poll_url or ""))
	print("[ZC Discord] command_secret=" .. (tostring(LogsCfg.command_secret or "") ~= "" and "configured" or "missing"))
end)

concommand.Add("zc_discord_command_secret_set", function(ply, _, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	LogsCfg.command_secret = table.concat(args, " ")
	SaveLogsCfg(LogsCfg)
	print("[ZC Discord Command] Secret " .. (LogsCfg.command_secret ~= "" and "updated" or "cleared") .. ".")
end)

concommand.Add("zc_discord_commands_enable", function(ply, _, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	LogsCfg.command_enabled = tonumber(args[1] or 1) == 1
	SaveLogsCfg(LogsCfg)
	print("[ZC Discord Command] " .. (LogsCfg.command_enabled and "enabled" or "disabled") .. ".")
end)

concommand.Add("discord_log", function(ply, _, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	DiscordLog(args[1] or "test")
end)
