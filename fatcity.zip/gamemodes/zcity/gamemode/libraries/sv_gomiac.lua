GOMIAC = GOMIAC or {}
local AC = GOMIAC
zb = zb or {}
zb.AC = AC -- old name, kept so anything referencing it keeps working

local LOG_FILE = "gomiac/log.txt"
local BAN_AT = 48 -- strike total that triggers a review (admin decides in Discord)
local STRIKE_DECAY = 60 -- seconds before a single strike expires
local BAN_MINUTES = 0 -- 0 = permanent
local BAN_REASON = "[GOMIAC] Ваше поведение было было помечено как подозрительное. Если вы хотите обжаловать это решение - напишите нам в дискорде."
local BLOCK_FAMILY_SHARE = true
local FAMILY_SHARE_REASON = "Family Share запрещён на этом сервере. Если вы хотите обжаловать это решение - напшиите в наш дискорд https://discord.gg/cxKsRMFa7A"
local FAMILY_SHARE_WL_FILE = "gomiac/familyshare_whitelist.json"

-- Discord webhook relay: every AC.Flag / Ban trigger, plus manual scans, get
-- reported here together with the offending player's garrysmod/lua/ file list.
local WEBHOOK_ENABLED = true
local WEBHOOK_URL = "http://141.98.7.178:3003/anticheat"
local WEBHOOK_SECRET   = "gachibass2024"
-- Discord user ID pinged when a player crosses BAN_AT and an admin must decide
-- (ban / forgive) through the select menu under the anticheat message.
local WEBHOOK_REVIEW_PING = "1210489969043578921"
local WEBHOOK_SCAN_TIMEOUT = 15 -- seconds to wait for the client's file list before giving up
local WEBHOOK_SCAN_RETRIES = 3
local WEBHOOK_SCAN_RETRY_DELAY = 3
local WEBHOOK_TEXT_LIMIT = 1800 -- Discord messages are limited to 2000 characters
local WEBHOOK_PART_DELAY = 0.5 -- seconds between multi-part webhook sends

file.CreateDir("gomiac")

local function Log(line)
	MsgC(Color(120, 255, 120), "[GOMIAC] ", color_white, line, "\n")
	file.Append(LOG_FILE, os.date("%Y-%m-%d %H:%M:%S ") .. line .. "\n")
end

local function TellAdmins(msg)
	for _, adm in player.Iterator() do
		if adm:IsAdmin() then
			adm:PrintMessage(HUD_PRINTTALK, "[GOMIAC] " .. msg)
		end
	end
end

--== family share whitelist ==================================================
-- Persistent list of borrower SteamID64s that are allowed to connect via
-- Family Share without being kicked. Managed with the "addwl" concommand.

local familyShareWhitelist = {}

local function NormalizeSteamID64(value)
	value = string.Trim(tostring(value or ""))
	if string.StartWith(string.upper(value), "STEAM_") then
		value = util.SteamIDTo64(string.upper(value)) or ""
	end
	if #value ~= 17 or not string.match(value, "^%d+$") or value == "00000000000000000" then return nil end
	return value
end

local function LoadFamilyShareWhitelist()
	local decoded = util.JSONToTable(file.Read(FAMILY_SHARE_WL_FILE, "DATA") or "")
	if not istable(decoded) then return end
	for sid64, allowed in pairs(decoded) do
		if allowed == true and NormalizeSteamID64(sid64) then
			familyShareWhitelist[sid64] = true
		end
	end
end

local function SaveFamilyShareWhitelist()
	file.Write(FAMILY_SHARE_WL_FILE, util.TableToJSON(familyShareWhitelist, true))
end

LoadFamilyShareWhitelist()

--== punishment ==============================================================

local function Ban(ply, reason)
	if not IsValid(ply) or ply.ac_banned then return end
	ply.ac_banned = true

	local id, nick = ply:SteamID(), ply:Nick()
	Log(("BAN %s (%s) -- %s"):format(nick, id, reason))
	TellAdmins(("%s banned: %s"):format(nick, reason))

	-- The host of a listen server cannot be kicked or banned by the engine. Say
	-- so loudly, otherwise testing locally looks like the anticheat is dead.
	if not game.IsDedicated() and ply:EntIndex() == 1 then
		Log("!! target is the listen server host -- engine cannot kick or ban them.")
		Log("!! detection DID fire. Test enforcement from a second client or a dedicated server.")
		return
	end

	-- ULib is what ULX itself bans through, so a ULib ban lands in ULX's own ban
	-- list and shows up in !banlist / XGUI like a manual ban. If ULX is not
	-- installed, or the call fails, fall back to the engine ban list so a
	-- detection never ends with the cheater still on the server.
	if ULib and ULib.ban then
		local ok, err = pcall(ULib.ban, ply, BAN_MINUTES, BAN_REASON, nil)
		if ok then
			Log("banned via ULX/ULib")
			return
		end
		Log("ULib.ban failed (" .. tostring(err) .. ") -- falling back to engine banid")
	else
		Log("ULX/ULib not installed -- using engine banid")
	end

	game.ConsoleCommand(("banid %d %s kick\n"):format(BAN_MINUTES, id))
	game.ConsoleCommand("writeid\n")
	if IsValid(ply) then ply:Kick(BAN_REASON) end
end

-- Assigned once the file-scan/webhook pipeline is defined further down. Kept
-- as a plain upvalue rather than a table field so a nil check below can tell
-- "not wired up yet" apart from "wired up but errored".
local ScanAndReport

-- severity 0 means "drop the action but do not punish" (used for plain rate
-- limits that a laggy client can hit innocently)
function AC.Flag(ply, reason, severity)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	severity = severity or 1
	if severity <= 0 then return end

	local now = CurTime()
	local strikes = ply.ac_strikes or {}
	local total = 0
	for i = #strikes, 1, -1 do
		if strikes[i].expires <= now then
			table.remove(strikes, i)
		else
			total = total + strikes[i].weight
		end
	end

	strikes[#strikes + 1] = {weight = severity, expires = now + STRIKE_DECAY}
	total = total + severity
	ply.ac_strikes = strikes

	Log(("STRIKE %s (%s) +%d = %d/%d -- %s"):format(ply:Nick(), ply:SteamID(), severity, total, BAN_AT, reason))

	if total < BAN_AT then return end
	if ply.ac_banned or ply.ac_review then return end

	-- Порог достигнут: автоматического бана больше нет. Файлы клиента
	-- запрашиваются сразу (пока он ещё на сервере -- после кика ответить на
	-- скан невозможно), а решение -- бан или снятие баллов -- принимает
	-- администрация в Discord через select menu под сообщением сработки.
	ply.ac_review = true
	Log(("REVIEW PENDING %s (%s) +%d = %d/%d -- %s"):format(ply:Nick(), ply:SteamID(), severity, total, BAN_AT, reason))

	local headline = ("Требуется действие -- STRIKE %s (%s) +%d = %d/%d -- %s")
		:format(ply:Nick(), ply:SteamID(), severity, total, BAN_AT, reason)

	if ScanAndReport then
		ScanAndReport(ply, headline, nil, WEBHOOK_REVIEW_PING)
	else
		-- pipeline not initialized (should not happen post-Bootstrap)
		Log("!! ScanAndReport недоступен -- сработка не отправлена")
	end
end

--== family share ============================================================
-- A family-shared copy reports a different license owner than the account that
-- connected. Kicked rather than banned: the owner SteamID belongs to someone who
-- did nothing wrong, and banning the borrower's ID is trivially sidestepped by
-- borrowing another library.

local function CheckFamilyShare(ply)
	if not BLOCK_FAMILY_SHARE or not IsValid(ply) then return end
	if not ply.OwnerSteamID64 then return end

	local owner = ply:OwnerSteamID64()
	local self64 = ply:SteamID64()
	if not owner or not self64 then return end
	if owner == "NULL" or owner == "0" then return end
	if owner == self64 then return end

	if familyShareWhitelist[self64] then
		Log(("family share ALLOWED %s (%s) -- whitelisted borrower; licence owned by %s")
			:format(ply:Nick(), ply:SteamID(), owner))
		return
	end

	Log(("family share KICK %s (%s) -- licence owned by %s"):format(ply:Nick(), ply:SteamID(), owner))
	TellAdmins(("%s kicked: family share (owner %s)"):format(ply:Nick(), owner))
	ply:Kick(FAMILY_SHARE_REASON)
end

hook.Add("PlayerInitialSpawn", "gomiac_familyshare", function(ply)
	-- deferred a tick: the licence owner is not populated the instant the player
	-- object exists
	timer.Simple(1, function()
		if IsValid(ply) then CheckFamilyShare(ply) end
	end)
end)

-- addwl <STEAM_0:X:Y или SteamID64> -- добавляет заёмщика (не владельца лицензии!)
-- в постоянный whitelist Family Share. Из игровой консоли доступно только
-- superadmin; из серверной консоли -- без ограничений.
local function FamilyShareWhitelistCommand(ply, cmd, args)
	local function Reply(text)
		text = "[GOMIAC] " .. text
		if IsValid(ply) then
			ply:PrintMessage(HUD_PRINTCONSOLE, text)
		else
			print(text)
		end
	end

	if IsValid(ply) and not ply:IsSuperAdmin() then
		Reply("команда доступна только superadmin.")
		return
	end

	local sid64 = NormalizeSteamID64(args[1])
	if not sid64 then
		Reply("использование: addwl <STEAM_0:X:Y или SteamID64>")
		return
	end

	if familyShareWhitelist[sid64] then
		Reply(sid64 .. " уже находится в whitelist Family Share.")
		return
	end

	familyShareWhitelist[sid64] = true
	SaveFamilyShareWhitelist()
	Log(("family share whitelist ADD %s by %s")
		:format(sid64, IsValid(ply) and (ply:Nick() .. " " .. ply:SteamID()) or "CONSOLE"))
	Reply(sid64 .. " добавлен в whitelist Family Share.")
end

concommand.Add("addwl", FamilyShareWhitelistCommand)

-- gomiac_forgive <STEAM_0:X:Y или SteamID64> -- обнуляет страйки игрока.
-- Вызывается ботом из Discord через очередь server-command (game.ConsoleCommand,
-- т.е. ply == NULL), из игры доступно только superadmin.
concommand.Add("gomiac_forgive", function(ply, cmd, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end

	local sid = NormalizeSteamID64(args[1])
	if not sid then return end

	local target
	for _, p in player.Iterator() do
		if p:SteamID64() == sid then target = p break end
	end

	if not IsValid(target) then
		-- оффлайн-игрок: его страйки и так исчезли вместе с entity
		Log(("forgive %s -- игрок не в сети, баллы уже сброшены"):format(sid))
		return
	end

	target.ac_strikes = {}
	target.ac_review = nil
	Log(("FORGIVE %s (%s) -- баллы сняты через Discord"):format(target:Nick(), target:SteamID()))
	target:PrintMessage(HUD_PRINTTALK, "[GOMIAC] Администрация сняла с вас баллы античита.")
end)

--== net rate limiting =======================================================
-- Per-message-per-player token buckets. The hook-spam vector (a client Think
-- hook firing net.Start every frame) shows up here as a bucket that never
-- refills fast enough, no matter which message the cheat picked.

local DEFAULT_RATE = {burst = 12, per = 1} -- 12 messages, refilling over 1s

-- keys are lowercased: net.Receivers is indexed case-insensitively
local RATES = {
	["zchatmessage"]       = {burst = 4,  per = 3},
	["zchattyping"]        = {burst = 6,  per = 3},
	["zchatglobalmessage"] = {burst = 3,  per = 5},
	["hg_phrase"]          = {burst = 4,  per = 3},
	["ply_take_item"]      = {burst = 3,  per = 1.5},
	["zb_specmode"]        = {burst = 3,  per = 5},
	["zb_choosespecply"]   = {burst = 6,  per = 2},
	["forgive_player"]     = {burst = 3,  per = 5},
	["zb_xp_get"]          = {burst = 4,  per = 2},
	["hg_pointshop_net"]   = {burst = 10, per = 1},
	["donatelogadmin"]     = {burst = 2,  per = 10},
	["chatwhisper"]        = {burst = 4,  per = 3},
}

-- Messages a non-admin must never be able to send. Every one of these is a
-- server authority handler; the mass-kick and round-nuke vectors live here.
local ADMIN_ONLY = {
	["adminsetgamemode"]   = true,
	["adminendround"]      = true,
	["adminsetgamequeue"]  = true,
	["zb_updateroundlist"] = true,
	["zb_requestroundlist"]= true,
	["donatelogadmin"]     = true,
}

local function CheckRate(ply, name)
	local cfg = RATES[name] or DEFAULT_RATE
	ply.ac_buckets = ply.ac_buckets or {}

	local b = ply.ac_buckets[name]
	local now = CurTime()
	if not b then
		b = {tokens = cfg.burst, last = now}
		ply.ac_buckets[name] = b
	end

	b.tokens = math.min(cfg.burst, b.tokens + (now - b.last) * (cfg.burst / cfg.per))
	b.last = now

	if b.tokens < 1 then
		b.over = (b.over or 0) + 1
		-- a few drops are lag; sustained overflow is automation
		if b.over % 25 == 0 then
			AC.Flag(ply, "net flood: " .. name, 3)
		end
		return false
	end

	b.tokens = b.tokens - 1
	b.over = 0
	return true
end

--== instaloot ===============================================================
-- ply_take_item trusts a 125u origin distance and nothing else: the eye trace
-- and the ZB_CanLootInventory hook only run in the Think loop that opens the
-- inventory, so a cheat that fires the net message directly skips both. We
-- re-apply them here, and require that the player actually opened this entity.

local LOOT_WINDOW = 20 -- seconds an opened inventory stays lootable
local LOOT_RANGE = 150 -- generous vs the 125u the handler already enforces

hook.Add("ZB_InventoryOpened", "gomiac_track_open", function(ply, ent)
	if not IsValid(ply) or not IsValid(ent) then return end
	ply.ac_openedinv = {ent = ent, at = CurTime()}
end)

-- The net payload cannot be inspected here (there is no way to rewind the read
-- buffer for the real handler), so this validates the player rather than the
-- item: instaloot never calls OpenInventory, so it never gets an entry here.
-- Returns allowed, reason, severity. Range and line-of-sight failures only drop
-- the action -- a ragdolled player's eye position is unreliable enough that
-- punishing them would ban legitimate players.
local function LootAllowed(ply)
	local opened = ply.ac_openedinv
	if not opened then return false, "loot without opening inventory", 4 end
	if not IsValid(opened.ent) then return false, "loot on removed entity", 0 end
	if CurTime() - opened.at > LOOT_WINDOW then return false, "loot on stale inventory", 0 end

	local ent = opened.ent
	local target = IsValid(ent.FakeRagdoll) and ent.FakeRagdoll or ent
	if ply:GetPos():DistToSqr(target:GetPos()) > LOOT_RANGE * LOOT_RANGE then
		return false, "loot out of range", 0
	end

	-- line of sight, so looting through walls is not possible
	local tr = util.TraceLine({
		start = ply:EyePos(),
		endpos = target:WorldSpaceCenter(),
		filter = {ply, IsValid(ply.FakeRagdoll) and ply.FakeRagdoll or ply, target, ent},
		mask = MASK_SOLID_BRUSHONLY,
	})
	if tr.Hit then return false, "loot through geometry", 0 end

	return true
end

--== usercmd analysis ========================================================
-- The old version of this section flagged plain flick-shots and ordinary aim
-- holds (broad angle-error cones checked every tick) and banned real players
-- for it. It has been replaced with two narrow, shot-confirmed detectors plus
-- exact input-automation signatures lifted from a specific cheat (pavetr.lua)
-- rather than generic movement/aim heuristics that a human can trigger too.
--
-- Both aim detectors require the flagged angle to be confirmed by an actual
-- shot fired shortly after (EntityFireBullets) and require repetition (2
-- confirmed episodes inside a rolling window) before punishing, specifically
-- so a single coincidence never bans anyone. The tracking detector additionally
-- requires the crosshair to stay glued while the input stream is idle -- a
-- human following someone with their mouse can never match that.

local function AngDiff(a, b)
	local p = math.AngleDifference(a.p, b.p)
	local y = math.AngleDifference(a.y, b.y)
	return math.sqrt(p * p + y * y)
end

local function AimPos(ply)
	local ent = IsValid(ply.FakeRagdoll) and ply.FakeRagdoll or ply
	-- ent.LookupBone, not ent:LookupBone -- the colon form is a call, and Lua will
	-- not parse it as a plain existence check
	local head = ent.LookupBone and ent:LookupBone("ValveBiped.Bip01_Head1")
	if head then
		local pos = ent:GetBonePosition(head)
		if pos then return pos end
	end
	return ent:WorldSpaceCenter()
end

-- degrees between where ply is looking and where target is
local function AimError(eyePos, fwd, target)
	local to = AimPos(target) - eyePos
	local len = to:Length()
	if len < 1 then return 180 end
	return math.deg(math.acos(math.Clamp(fwd:Dot(to / len), -1, 1)))
end

local function ClosestTarget(ply, eyePos, fwd)
	local best, bestErr = nil, 180
	for _, other in player.Iterator() do
		if other ~= ply and other:Alive() and not other.ac_banned then
			local err = AimError(eyePos, fwd, other)
			if err < bestErr then best, bestErr = other, err end
		end
	end
	return best, bestErr
end

-- silent aim: cl_fs-style cheats rewrite cmd:SetViewAngles() only on the
-- command that actually reaches the server, leaving the client's own visible
-- camera untouched. That command jumps hard onto a target with essentially
-- no mouse movement behind it.
local SILENT_JUMP_DEG   = 7    -- minimum command-to-command angle jump
local SILENT_MOUSE_MAX  = 2    -- GetMouseX()+GetMouseY() must be at or below this
local SILENT_ERR_DEG    = 5    -- must land within this of a player after the jump

-- aimbot tracking (soft-lock): the view is HELD inside a narrow cone on a
-- moving target for a long stretch while the player contributes no input.
-- That combination is the discriminator: a human following a strafing player
-- must keep moving their mouse, otherwise the view falls behind and breaks
-- the cone within a few ticks. Only automation can keep the crosshair glued
-- with an idle input stream. The old version (any 12 ticks within a 5 degree
-- cone + a shot) flagged ordinary tracking-while-shooting, i.e. the core
-- mechanic of every shooter, and banned innocent players.
local AIM_FOLLOW_DEG        = 5     -- cone that counts as "still on target"
local AIM_FOLLOW_TICKS      = 60    -- consecutive on-target ticks required (~1s @66 tick)
local AIM_FOLLOW_TURN       = 1.5   -- max degrees the view may move per tick while tracking
local AIM_FOLLOW_TRAVEL     = 12    -- min degrees the VIEW itself must travel during the
                                    -- episode (proves the target dragged the view along;
                                    -- watching someone run straight away never matches)
local FOLLOW_MOUSEFREE_MAX  = 3     -- GetMouseX()+GetMouseY() at/below this = "no input"
local FOLLOW_MOUSEFREE_FRAC = 0.95  -- required share of input-free ticks in the episode
local FOLLOW_STRIKE_WEIGHT  = BAN_AT / 2 -- a single episode alone never bans

-- Both detectors additionally require a shot fired within this window of the
-- suspicious angle, and this many confirmed episodes inside CONFIRM_WINDOW
-- seconds, before AC.Flag is actually called.
local CONFIRM_SHOT_WINDOW = 0.35
local CONFIRM_EPISODES_NEEDED = 2
local CONFIRM_EPISODES_WINDOW = 30

local function RegisterConfirmedEpisode(ply, key, reason, weight)
	local now = CurTime()
	local episodes = ply["ac_" .. key .. "episodes"] or {}
	for i = #episodes, 1, -1 do
		if now - episodes[i] > CONFIRM_EPISODES_WINDOW then table.remove(episodes, i) end
	end
	episodes[#episodes + 1] = now
	ply["ac_" .. key .. "episodes"] = episodes

	if #episodes >= CONFIRM_EPISODES_NEEDED then
		ply["ac_" .. key .. "episodes"] = {}
		AC.Flag(ply, reason, weight or BAN_AT)
	end
end

-- Exact command patterns used by pavetr.lua. These are intentionally not
-- generic bhop/autostrafe heuristics: ordinary movement can look identical.
-- Requiring a long uninterrupted parity pattern avoids punishing normal input.
local INPUT_PATTERN_TICKS = 48
local FASTWALK_MIN_SIDE = 4000

local function UpdateExactInputPatterns(ply, cmd)
	local tick = cmd:TickCount()
	local even = tick % 2 == 0
	local attack = cmd:KeyDown(IN_ATTACK)
	local attack2 = cmd:KeyDown(IN_ATTACK2)
	local use = cmd:KeyDown(IN_USE)
	local side = cmd:GetSideMove()
	local forward = cmd:GetForwardMove()

	-- pavetr clicker adds primary attack on even ticks and secondary attack on
	-- odd ticks. Require exactly one attack button, otherwise normal combined
	-- weapon controls cannot accidentally extend the sequence.
	local clickerMatch = attack ~= attack2 and ((even and attack) or (not even and attack2))
	ply.ac_clickerpattern = clickerMatch and (ply.ac_clickerpattern or 0) + 1 or 0
	if ply.ac_clickerpattern >= INPUT_PATTERN_TICKS then
		ply.ac_clickerpattern = 0
		AC.Flag(ply, "input automation: attack buttons alternate by command parity", 3)
	end

	-- pavetr auto-use is present on every even command and absent on every odd
	-- command. A held use key does not match because it remains set every tick.
	local autoUseMatch = use == even
	ply.ac_autousepattern = autoUseMatch and (ply.ac_autousepattern or 0) + 1 or 0
	if ply.ac_autousepattern >= INPUT_PATTERN_TICKS then
		ply.ac_autousepattern = 0
		AC.Flag(ply, "input automation: use key pulses on every second command", 3)
	end

	-- pavetr fastwalk adds +5000/-5000 side move on alternating ticks while
	-- moving forward/back. The engine may clamp the value, so match direction
	-- and a conservative magnitude rather than the exact number 5000.
	local fastwalkMatch = forward ~= 0 and math.abs(side) >= FASTWALK_MIN_SIDE
		and ((even and side > 0) or (not even and side < 0))
	ply.ac_fastwalkpattern = fastwalkMatch and (ply.ac_fastwalkpattern or 0) + 1 or 0
	if ply.ac_fastwalkpattern >= INPUT_PATTERN_TICKS then
		ply.ac_fastwalkpattern = 0
		AC.Flag(ply, "movement automation: extreme side move alternates by command parity", 3)
	end
end

hook.Remove("StartCommand", "gomiac_usercmd")
hook.Remove("EntityFireBullets", "gomiac_shot")

hook.Add("StartCommand", "gomiac_usercmd", function(ply, cmd)
	if not IsValid(ply) or ply.ac_banned or ply:IsBot() or not ply:Alive() then return end

	UpdateExactInputPatterns(ply, cmd)

	if IsValid(ply:GetVehicle()) then
		ply.ac_lastang = nil
		ply.ac_silentcandidate = nil
		ply.ac_follow = nil
		return
	end

	local ang = cmd:GetViewAngles()
	local prev = ply.ac_lastang
	ply.ac_lastang = Angle(ang.p, ang.y, 0)
	if not prev then return end

	local eyePos = ply:EyePos()
	local fwd = ang:Forward()
	local target, err = ClosestTarget(ply, eyePos, fwd)
	local angDelta = AngDiff(ang, prev)
	local mouseTotal = math.abs(cmd:GetMouseX()) + math.abs(cmd:GetMouseY())

	-- silent aim: a big command-angle jump, virtually no mouse movement behind
	-- it, attack held, and it lands right on a player.
	if target and cmd:KeyDown(IN_ATTACK) and mouseTotal <= SILENT_MOUSE_MAX
		and angDelta >= SILENT_JUMP_DEG and err <= SILENT_ERR_DEG then
		ply.ac_silentcandidate = {
			target = target, ang = Angle(ang.p, ang.y, 0), err = err,
			jump = angDelta, mouse = mouseTotal, at = CurTime(),
		}
	end

	-- aimbot tracking (soft-lock): the view stays glued to a moving target
	-- within a tight cone while the input stream is idle. Episode state tracks
	-- how far the view travelled and how many ticks had no input at all; both
	-- thresholds are checked when a shot confirms the episode. Keyboard turns
	-- (+left/+right) count as input too, so bind-turners never match.
	if target and err < AIM_FOLLOW_DEG and target:GetVelocity():LengthSqr() > 400
		and angDelta <= AIM_FOLLOW_TURN then
		local st = ply.ac_follow
		if st and st.target == target then
			st.ticks = st.ticks + 1
			st.travel = st.travel + angDelta
			if mouseTotal <= FOLLOW_MOUSEFREE_MAX
				and not (cmd:KeyDown(IN_LEFT) or cmd:KeyDown(IN_RIGHT)) then
				st.mousefree = st.mousefree + 1
			end
		else
			ply.ac_follow = {target = target, ticks = 1, travel = 0, mousefree = 0}
		end
	else
		ply.ac_follow = nil
	end
end)

hook.Add("EntityFireBullets", "gomiac_shot", function(ent)
	if not IsValid(ent) or not ent:IsPlayer() then return end
	local now = CurTime()

	local candidate = ent.ac_silentcandidate
	if candidate and now - candidate.at <= CONFIRM_SHOT_WINDOW then
		ent.ac_silentcandidate = nil
		RegisterConfirmedEpisode(ent, "silent",
			("silent aim: %.1f deg command jump with %d mouse input onto %s, confirmed by shot")
				:format(candidate.jump, candidate.mouse, IsValid(candidate.target) and candidate.target:Nick() or "?"))
	end

	local st = ent.ac_follow
	if st and st.ticks >= AIM_FOLLOW_TICKS
		and st.travel >= AIM_FOLLOW_TRAVEL
		and st.mousefree >= st.ticks * FOLLOW_MOUSEFREE_FRAC then
		ent.ac_follow = nil -- a fresh episode is required before the next report
		RegisterConfirmedEpisode(ent, "follow",
			("aimbot tracking: %d ticks glued within %.0f deg, view travelled %.0f deg, %d%% of ticks without input, on %s, confirmed by shot")
				:format(st.ticks, AIM_FOLLOW_DEG, st.travel,
					math.floor(100 * st.mousefree / st.ticks + 0.5),
					IsValid(st.target) and st.target:Nick() or "?"),
			FOLLOW_STRIKE_WEIGHT)
	end
end)

--== wrapping ================================================================
-- Everything above is applied by wrapping the handlers that already exist, so
-- no gamemode file is modified and the anticheat can be dropped or updated on
-- its own.

local origReceive = AC.origReceive or net.Receive
AC.origReceive = origReceive

-- Messages that must still reach their handler for a player already flagged
-- as ac_banned. Only the file-scan response: it is requested specifically
-- because the player got flagged, so blocking it here would make the whole
-- pre-ban scan pointless.
local BANNED_EXEMPT = {
	["gomiac_filescan_res"] = true,
}

local guarded = {}

local function Wrap(name, fn)
	local key = string.lower(name)
	guarded[key] = fn

	origReceive(name, function(len, ply)
		local inner = guarded[key]
		if not inner then return end
		if not IsValid(ply) or not ply:IsPlayer() then return end
		if ply.ac_banned and not BANNED_EXEMPT[key] then return end

		if ADMIN_ONLY[key] and not ply:IsAdmin() then
			-- no rate limit, no second chance: a client that sends this is not
			-- a client that mistyped something
			Ban(ply, "sent admin-only net message: " .. name)
			return
		end

		if not CheckRate(ply, key) then return end

		if key == "ply_take_item" then
			local ok, why, severity = LootAllowed(ply)
			if not ok then
				AC.Flag(ply, "instaloot: " .. why, severity)
				return
			end
		end

		inner(len, ply)
	end)
end

local function WrapAll()
	local receivers = net.Receivers
	if not receivers then
		Log("net.Receivers unavailable -- net protection disabled")
		return
	end

	local n = 0
	for name, fn in pairs(table.Copy(receivers)) do
		Wrap(name, fn)
		n = n + 1
	end

	-- catch handlers registered after this point, including hotloads that
	-- re-register an already guarded message
	net.Receive = function(name, fn)
		Wrap(name, fn)
	end

	Log(("guarding %d net messages"):format(n))
end

--== discord webhook / lua folder dump =======================================
-- Reports every AC.Flag / Ban trigger to an external webhook relay, together
-- with files placed directly in the offending player's garrysmod/lua/ (see
-- ANTICHEAT_API.md). Runs standalone, no dependency on any other addon.

util.AddNetworkString("gomiac_filescan_req")
util.AddNetworkString("gomiac_filescan_res")
util.AddNetworkString("gomiac_screengrab_req")
util.AddNetworkString("gomiac_screengrab_res")

-- Легитимные дампы аддонов в lua/, отфильтровываются из любого отчёта
-- (дублирует фильтр в cl_fs.lua на случай необновлённых клиентов)
local SCAN_EXCLUDE = {
	["lua/glide_helicopters_source.txt"] = true,
	["lua/glide_source.txt"] = true,
	["lua/send.txt"] = true,
	["lua/vfire_source.txt"] = true,
	["lua/wos_source.txt"] = true,
}

local function FilterScanFiles(files)
	if not istable(files) then return files end
	local out = {}
	for _, f in ipairs(files) do
		if not SCAN_EXCLUDE[string.lower(tostring(f))] then out[#out + 1] = f end
	end
	return out
end

-- keyed by SteamID64
local pendingScans = {}

local function FinishFileScan(sid, request, files, failure)
	if pendingScans[sid] ~= request then return end
	pendingScans[sid] = nil

	files = FilterScanFiles(files)

	for _, callback in ipairs(request.callbacks) do
		local ok, err = pcall(callback, files, failure)
		if not ok then Log("file scan callback error: " .. tostring(err)) end
	end
end

-- Queues onto an in-flight scan for the same player instead of starting a
-- second one, so a manual "ulx gomiacfiles" run during an automatic pre-ban
-- scan (or vice versa) doesn't race and doesn't cut the other one short.
local function RequestFileScan(ply, callback)
	if not IsValid(ply) or not ply:IsPlayer() then
		callback(nil, "игрок недоступен")
		return
	end

	local sid = ply:SteamID64()
	local current = pendingScans[sid]
	if current then
		current.callbacks[#current.callbacks + 1] = callback
		return
	end

	local request = {
		callbacks = {callback},
		acknowledged = false,
		chunks = {},
		chunkCount = nil,
		attempts = 0,
	}
	pendingScans[sid] = request

	local function SendRequest()
		if pendingScans[sid] ~= request or request.acknowledged or not IsValid(ply) then return end
		request.attempts = request.attempts + 1
		net.Start("gomiac_filescan_req")
		net.Send(ply)

		if request.attempts < WEBHOOK_SCAN_RETRIES then
			timer.Simple(WEBHOOK_SCAN_RETRY_DELAY, SendRequest)
		end
	end
	SendRequest()

	timer.Simple(WEBHOOK_SCAN_TIMEOUT, function()
		if pendingScans[sid] == request then
			local failure = request.acknowledged
				and "клиент подтвердил запрос, но не передал полный ответ"
				or ("клиент не подтвердил запрос после %d попыток; вероятно, cl_fs.lua не загружен или произошла клиентская Lua-ошибка")
					:format(request.attempts)
			Log(("file scan timeout for %s (%s): %s")
				:format(ply:Nick(), ply:SteamID(), failure))
			FinishFileScan(sid, request, nil, failure)
		end
	end)
end

net.Receive("gomiac_filescan_res", function(len, ply)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	local sid = ply:SteamID64()
	local request = pendingScans[sid]
	if not request then return end

	local packetType = net.ReadUInt(8)

	if packetType == 0 then
		request.acknowledged = true
		return
	end

	if packetType == 1 then
		local index = net.ReadUInt(16)
		local count = net.ReadUInt(16)
		local bytes = net.ReadUInt(32)

		if index < 1 or count < 1 or index > count or count > 512 or bytes < 1 or bytes > 60000 then
			Log(("invalid file scan chunk from %s (%s)"):format(ply:Nick(), ply:SteamID()))
			FinishFileScan(sid, request, nil, "клиент прислал некорректную часть ответа")
			return
		end

		if request.chunkCount and request.chunkCount ~= count then
			Log(("mismatched file scan chunks from %s (%s)"):format(ply:Nick(), ply:SteamID()))
			FinishFileScan(sid, request, nil, "части ответа клиента имеют несовпадающий размер")
			return
		end
		request.chunkCount = count
		request.chunks[index] = net.ReadData(bytes)

		if table.Count(request.chunks) < count then return end

		local raw = table.concat(request.chunks)
		local decoded = util.JSONToTable(util.Decompress(raw) or "")
		local files = decoded and istable(decoded.files) and decoded.files or nil
		FinishFileScan(sid, request, files,
			files and nil or "не удалось распаковать или прочитать ответ клиента")
		return
	end

	-- legacy/unknown packet type -- treat as a single-shot best-effort reply
	-- `len` is in bits and 8 bits were already consumed by the packet type
	local raw = net.ReadData(math.max(0, math.floor((len - 8) / 8)))
	local decoded = util.JSONToTable(util.Decompress(raw) or raw or "")
	local files = decoded and istable(decoded.files) and decoded.files or nil
	FinishFileScan(sid, request, files,
		files and nil or "не удалось прочитать ответ старого клиента")
end)

--== screengrab ==============================================================
-- Два JPEG с клиента (обычный захват + экспериментальный через render target).
-- Кадры приходят чанками того же формата, что и файл-скан, слот 1 = normal,
-- слот 2 = experimental; пакет типа 2 = "слот пуст" (захват не удался).

local pendingShots = {} -- keyed by SteamID64
-- Слот 2 -- движковый скриншот (jpeg): клиент ждёт файл от движка до 4 с,
-- поэтому таймаут заметно больше времени самого захвата.
local SCREENSHOT_TIMEOUT = 20
local SCREENSHOT_MAX_CHUNKS = 64

local function FinishScreenshots(sid, request, shots)
	if pendingShots[sid] ~= request then return end
	pendingShots[sid] = nil

	for _, callback in ipairs(request.callbacks) do
		local ok, err = pcall(callback, shots)
		if not ok then Log("screenshot callback error: " .. tostring(err)) end
	end
end

local function RequestScreenshots(ply, callback)
	if not IsValid(ply) or not ply:IsPlayer() then
		callback(nil)
		return
	end

	local sid = ply:SteamID64()
	local current = pendingShots[sid]
	if current then
		current.callbacks[#current.callbacks + 1] = callback
		return
	end

	local request = {
		callbacks = {callback},
		acknowledged = false,
		slots = {},
	}
	pendingShots[sid] = request

	net.Start("gomiac_screengrab_req")
	net.Send(ply)

	timer.Simple(SCREENSHOT_TIMEOUT, function()
		if pendingShots[sid] == request then
			Log(("screenshot timeout for %s (%s)%s")
				:format(ply:Nick(), ply:SteamID(),
					request.acknowledged and "" or " (нет подтверждения от клиента)"))
			FinishScreenshots(sid, request, nil)
		end
	end)
end

local function ScreenshotSlotDone(sid, request, slot, data)
	request.done = request.done or {}
	if request.done[slot] ~= nil then return end
	request.done[slot] = data or ""

	if request.done[1] ~= nil and request.done[2] ~= nil then
		FinishScreenshots(sid, request,
			{normal = request.done[1], experimental = request.done[2]})
	end
end

net.Receive("gomiac_screengrab_res", function(len, ply)
	if not IsValid(ply) or not ply:IsPlayer() then return end
	local sid = ply:SteamID64()
	local request = pendingShots[sid]
	if not request then return end

	local packetType = net.ReadUInt(8)

	if packetType == 0 then
		request.acknowledged = true
		return
	end

	if packetType == 2 then -- slot empty (capture failed on client)
		local slot = net.ReadUInt(8)
		if slot >= 1 and slot <= 2 then
			ScreenshotSlotDone(sid, request, slot, "")
		end
		return
	end

	if packetType ~= 1 then return end

	local slot = net.ReadUInt(8)
	local index = net.ReadUInt(16)
	local count = net.ReadUInt(16)
	local bytes = net.ReadUInt(32)

	if slot < 1 or slot > 2 then return end
	if index < 1 or count < 1 or index > count or count > SCREENSHOT_MAX_CHUNKS or bytes < 1 or bytes > 60000 then
		Log(("invalid screenshot chunk from %s (%s)"):format(ply:Nick(), ply:SteamID()))
		FinishScreenshots(sid, request, nil)
		return
	end

	local slotState = request.slots[slot]
	if not slotState then
		slotState = {chunks = {}, count = nil}
		request.slots[slot] = slotState
	end

	if slotState.count and slotState.count ~= count then
		Log(("mismatched screenshot chunks from %s (%s)"):format(ply:Nick(), ply:SteamID()))
		FinishScreenshots(sid, request, nil)
		return
	end
	slotState.count = count
	slotState.chunks[index] = net.ReadData(bytes)

	if table.Count(slotState.chunks) < count then return end

	ScreenshotSlotDone(sid, request, slot, table.concat(slotState.chunks))
end)

local function BuildWebhookParts(playerInfo, headline, files, scanFailure)
	local header = ("%s\nФайлы у %s(%s)\n"):format(headline, playerInfo.nick, playerInfo.steamid)
	local stamp = os.date("%d.%m.%Y %H:%M:%S")

	if not files or #files == 0 then
		return {header .. (files and "(файлы не найдены)" or
			("[не удалось получить список файлов: %s]"):format(scanFailure or "клиент не ответил")) .. "\n" .. stamp}
	end

	local bodyLimit = math.max(256, WEBHOOK_TEXT_LIMIT - #header - 80)
	local parts, current = {}, ""
	for _, path in ipairs(files) do
		local candidate = current == "" and path or (current .. "\n" .. path)
		if current ~= "" and #candidate > bodyLimit then
			parts[#parts + 1] = current
			current = path
		else
			current = candidate
		end
	end
	if current ~= "" then parts[#parts + 1] = current end

	local out = {}
	for i, chunk in ipairs(parts) do
		out[i] = ("%sЧасть %d/%d\n%s\n%s"):format(header, i, #parts, chunk, stamp)
	end
	return out
end

local function SendWebhook(playerInfo, headline, files, scanFailure, pingUser, shots)
	if not WEBHOOK_ENABLED then return end
	local parts = BuildWebhookParts(playerInfo, headline, files, scanFailure)

	-- base64 JPEG-кадры: [1] = обычный захват, [2] = экспериментальный (RT).
	-- Уходят только с первой частью сообщения.
	local shotPayload
	if istable(shots) then
		shotPayload = {}
		if shots.normal and #shots.normal > 0 then
			shotPayload[#shotPayload + 1] = util.Base64Encode(shots.normal)
		end
		if shots.experimental and #shots.experimental > 0 then
			shotPayload[#shotPayload + 1] = util.Base64Encode(shots.experimental)
		end
		if #shotPayload == 0 then shotPayload = nil end
	end

	local function SendPart(i)
		if i > #parts then
			Log(("webhook publish complete: %d part(s)"):format(#parts))
			return
		end

		-- ping/screenshots ride on the first part only
		local payload = {content = parts[i]}
		if i == 1 then
			if pingUser then payload.ping = pingUser end
			payload.screenshots = shotPayload
		end

		HTTP({
			url = WEBHOOK_URL,
			method = "POST",
			headers = {["Content-Type"] = "application/json", ["x-anticheat-secret"] = WEBHOOK_SECRET},
			body = util.TableToJSON(payload),
			success = function(code, body)
				Log(("webhook part %d/%d responded %s: %s"):format(i, #parts, tostring(code), tostring(body)))
				timer.Simple(WEBHOOK_PART_DELAY, function() SendPart(i + 1) end)
			end,
			failed = function(err)
				Log(("webhook part %d/%d FAILED: %s"):format(i, #parts, tostring(err)))
				timer.Simple(WEBHOOK_PART_DELAY, function() SendPart(i + 1) end)
			end,
		})
	end
	SendPart(1)
end

-- playerInfo is captured up front, not read from `ply` inside the callback:
-- by the time the scan finishes the offending player may already have been
-- kicked, at which point ply:Nick()/:SteamID() can no longer be trusted.
function AC.ScanAndReport(ply, headline, done, pingUser)
	if not IsValid(ply) then
		if done then done(nil, "игрок недоступен") end
		return
	end

	local playerInfo = {nick = ply:Nick(), steamid = ply:SteamID()}
	RequestFileScan(ply, function(files, failure)
		RequestScreenshots(ply, function(shots)
			SendWebhook(playerInfo, headline, files, failure, pingUser, shots)
			if done then done(files, failure) end
		end)
	end)
end
ScanAndReport = AC.ScanAndReport

hook.Add("PlayerDisconnected", "gomiac_filescan_cleanup", function(ply)
	local sid = ply:SteamID64()
	if not sid then return end
	local request = pendingScans[sid]
	if request then
		FinishFileScan(sid, request, nil, "игрок отключился до завершения передачи")
	end
	local shotRequest = pendingShots[sid]
	if shotRequest then
		FinishScreenshots(sid, shotRequest, nil)
	end
end)

concommand.Add("gomiac_webhook_test", function(ply)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end
	SendWebhook({nick = "TEST", steamid = "STEAM_0:0:1"},
		"Сработка АЧ: TEST", nil, "тестовое сообщение, файлы не запрашивались")
end)

-- ulx gomiacfiles <игрок> -- superadmin-only manual file listing, no strike,
-- no kick, no ban. Just runs the same scan+webhook pipeline as a real
-- detection so admins can eyeball a player's lua/ folder on suspicion alone.
if ulx and ULib then
	local function GomiacFilesCommand(callingPly, targetPly)
		if IsValid(callingPly) and not callingPly:IsSuperAdmin() then
			ULib.tsay(callingPly, "команда доступна только superadmin.")
			return
		end
		if not IsValid(targetPly) then
			ULib.tsay(callingPly, "игрок недоступен.")
			return
		end

		local targetName = targetPly:Nick()
		local headline = ("Сработка АЧ: MANUAL FILE SCAN %s (%s), requested by %s")
			:format(targetName, targetPly:SteamID(),
				IsValid(callingPly) and (callingPly:Nick() .. " (" .. callingPly:SteamID() .. ")") or "CONSOLE")

		local function Reply(text)
			if IsValid(callingPly) then ULib.tsay(callingPly, text) else print("[GOMIAC] " .. text) end
		end

		AC.ScanAndReport(targetPly, headline, function(files, failure)
			if files then
				Reply(("получено %d файлов у %s; список отправлен в Discord.")
					:format(#files, targetName))
			else
				Reply(("не удалось получить файлы у %s: %s. Диагностика отправлена в Discord.")
					:format(targetName, failure or "неизвестная ошибка"))
			end
		end)
	end

	local gomiacfiles = ulx.command("GOMIAC", "ulx gomiacfiles", GomiacFilesCommand, "!gomiacfiles")
	gomiacfiles:addParam({type = ULib.cmds.PlayerArg})
	gomiacfiles:defaultAccess(ULib.ACCESS_SUPERADMIN)
	gomiacfiles:help("Запросить список файлов garrysmod/lua/ у игрока без наказания (только superadmin).")

	Log("registered ULX command: ulx gomiacfiles (superadmin)")
end

--== unauthenticated concommands =============================================
-- loader.lua registers these with no rank check at all; one of them writes to
-- disk. Re-registering replaces the handler without touching the file.

local function SecureCommands()
	local function adminOnly(name, fn)
		concommand.Add(name, function(ply, cmd, args, argStr)
			if IsValid(ply) and not ply:IsAdmin() then
				AC.Flag(ply, "used admin concommand: " .. name, 6)
				return
			end
			fn(ply, cmd, args, argStr)
		end)
	end

	adminOnly("zb_getmodeschances", function(ply)
		local out = util.TableToJSON(zb.ModesChances or {}, true)
		if IsValid(ply) then ply:zChatPrint(out) else print(out) end
	end)

	adminOnly("zb_setmodechance", function(ply, cmd, args)
		local mode, chance = args[1], tonumber(args[2])
		if not mode or not chance or not zb.ModesChances or not zb.ModesChances[mode] then return end
		zb.ModesChances[mode] = chance
	end)

	adminOnly("zb_savemodeschances", function()
		file.Write("zbattle/modeschances.json", util.TableToJSON(zb.ModesChances or {}, true))
	end)
end

--== startup =================================================================

local function Bootstrap()
	if AC.ready then return end
	AC.ready = true

	WrapAll()
	SecureCommands()
	Log("GOMIAC online")
end

-- Deferred, because loader.lua registers its concommands after loading this
-- folder and modes register their net handlers later still. Hooked in several
-- places so a hotload, a fresh boot, and a map change all reach it.
timer.Simple(0, Bootstrap)
hook.Add("Initialize", "gomiac_bootstrap", function() timer.Simple(0, Bootstrap) end)
hook.Add("InitPostEntity", "gomiac_bootstrap2", function() timer.Simple(0, Bootstrap) end)

concommand.Add("gomiac_status", function(ply)
	local function out(s)
		if IsValid(ply) then ply:PrintMessage(HUD_PRINTCONSOLE, s) else print(s) end
	end

	if IsValid(ply) and not ply:IsAdmin() then return end

	out("== GOMIAC status ==")
	out("bootstrapped: " .. tostring(AC.ready == true))
	out("guarded net messages: " .. table.Count(guarded))
	out("ban backend: " .. (ULib and ULib.ban and "ULX / ULib" or "engine banid"))
	out("ban at: " .. BAN_AT .. " strikes, decay " .. STRIKE_DECAY .. "s")
	out("dedicated server: " .. tostring(game.IsDedicated()))

	local now = CurTime()
	for _, p in player.Iterator() do
		local total = 0
		for _, s in ipairs(p.ac_strikes or {}) do
			if s.expires > now then total = total + s.weight end
		end
		out(("  %s (%s): %d/%d strikes%s"):format(p:Nick(), p:SteamID(), total, BAN_AT,
			p.ac_banned and " [BANNED]" or ""))
	end
end)

hook.Add("PlayerDisconnected", "gomiac_cleanup", function(ply)
	ply.ac_strikes = nil
	ply.ac_buckets = nil
	ply.ac_lastang = nil
	ply.ac_silentcandidate = nil
	ply.ac_follow = nil
	ply.ac_review = nil
	ply.ac_silentepisodes = nil
	ply.ac_followepisodes = nil
	ply.ac_clickerpattern = nil
	ply.ac_autousepattern = nil
	ply.ac_fastwalkpattern = nil
end)
