local MODE = MODE
local HNS_SCHIZO_PHRASES = {
    "УБЕЙ ВСЕХ",
    "ОНИ ЗАСЛУЖИВАЮТ СМЕРТИ",
    "НЕ ДАЙ ИМ СКРЫТЬСЯ",
    "ОНИ НАБЛЮДАЮТ",
    "ПОКОНЧИ С ЭТИМ",
    "НЕ ЖАЛЕЙ ИХ",
    "ЗАСТАВЬ ИХ ЗАПЛАТИТЬ",
    "СЛУШАЙ ГОЛОСА",
    "ЗАКОНЧИ ОхОТУ",
    "РАЗДЕЛЯЙ И ВЛАСТВУЙ",
    "OwO",
}

local hnsSchizoNextAt = 0
local hnsSchizoShowUntil = 0
local hnsSchizoBatch = {}

hook.Add("HUDPaint", "HNS_SchizoFlashes", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    if not ply:GetNetVar("HNS_Schizo", false) then return end

    local t = CurTime()

    if hnsSchizoShowUntil == 0 or (t >= hnsSchizoShowUntil and t >= hnsSchizoNextAt) then
        hnsSchizoBatch = {}
        for i = 1, 12 do
            hnsSchizoBatch[i] = HNS_SCHIZO_PHRASES[math.random(#HNS_SCHIZO_PHRASES)]
        end
        hnsSchizoShowUntil = t + 5
        hnsSchizoNextAt = hnsSchizoShowUntil + 10
    end

    if t < hnsSchizoShowUntil then
        local w, h = ScrW(), ScrH()
        local alpha = math.Clamp(200 + 55 * math.sin(t * 15), 80, 255)
        surface.SetFont("Trebuchet24")
        for i = 1, #hnsSchizoBatch do
            local x = math.random(math.floor(w * 0.1), math.floor(w * 0.9))
            local y = math.random(math.floor(h * 0.1), math.floor(h * 0.9))
            draw.SimpleTextOutlined(
                hnsSchizoBatch[i], "Trebuchet24", x, y,
                Color(255, 0, 0, alpha),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER,
                1, Color(0, 0, 0, alpha * 0.6)
            )
        end
    end
end)

MODE.name = "hideseek"
local roundEnding = false

net.Receive("hns_start", function()
    timer.Simple(0.2, function()
        sound.PlayFile("sound/zbattle/briefing.ogg", "noplay", function(station)
            if IsValid(station) then
                station:Play()
            else
                surface.PlaySound("zbattle/briefing.ogg")
            end
        end)
    end)
end)

local teams = {
    [0] = {
        objective = "ты че далбаеб",
        name = "SWAT Agent",
        color1 = Color(68, 10, 255),
        color2 = Color(68, 10, 255)
    },
    [1] = {
        objective = "Прячься пока не стало слишком поздно.",
        name = "Прячущийся",
        color1 = Color(0, 190, 190),
        color2 = Color(0, 190, 190)
    },
    [2] = {
        objective = "Они это заслужили.",
        name = "Охотник",
        color1 = Color(255, 0, 0),
        color2 = Color(228, 49, 49)
    },
}

local function drawSeekerWaitingScreen()
    surface.SetFont("ZB_HomicideMediumLarge")
    local txt1 = "Твоя роль: "
    local txt2 = "Искатель"
    local tw1, th1 = surface.GetTextSize(txt1)
    local tw2, th2 = surface.GetTextSize(txt2)
    local totalW = tw1 + tw2
    local startX = ScrW() * 0.5 - totalW / 2
    local y = ScrH() * 0.35

    surface.SetTextColor(255, 255, 255, 255)
    surface.SetTextPos(startX, y)
    surface.DrawText(txt1)

    surface.SetTextColor(255, 0, 0, 255)
    surface.SetTextPos(startX + tw1, y)
    surface.DrawText(txt2)

    local txt3 = "Дороги назад нету, уничтожьте всех, кто прячется"
    surface.SetFont("ZB_HomicideMedium")
    local tw3 = surface.GetTextSize(txt3)
    surface.SetTextColor(255, 255, 255, 255)
    surface.SetTextPos(ScrW() * 0.5 - tw3 / 2, ScrH() * 0.45)
    surface.DrawText(txt3)
end

function MODE:RenderScreenspaceEffects()
    zb.RemoveFade()

    local ply = LocalPlayer()
    if IsValid(ply) and ply:Team() == 2 and not ply:Alive() and zb.ROUND_START + 61 > CurTime() then
        surface.SetDrawColor(0, 0, 0, 255)
        surface.DrawRect(-1, -1, ScrW() + 1, ScrH() + 1)
        return
    end

    if zb.ROUND_START + 7.5 < CurTime() then return end
    local fade = math.Clamp(zb.ROUND_START + 7.5 - CurTime(), 0, 1)
    surface.SetDrawColor(0, 0, 0, 255 * fade)
    surface.DrawRect(-1, -1, ScrW() + 1, ScrH() + 1)
end

local posadd = 0
local posaddTimer = 0
local timerSlideStart = 0

function MODE:HUDPaint()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    if ply:Team() == 2 and not ply:Alive() and zb.ROUND_START + 61 > CurTime() then
        drawSeekerWaitingScreen()
        local timeLeft = math.ceil(zb.ROUND_START + 61 - CurTime())
        if timeLeft > 0 then
        end
        return
    end

    if zb.ROUND_START + 60 > CurTime() then
        posadd = Lerp(FrameTime() * 5, posadd or 0, zb.ROUND_START + 7.3 < CurTime() and 0 or -ScrW() * 0.4)
    end

    if zb.ROUND_START + 60 < CurTime() then
        if timerSlideStart == 0 then
            timerSlideStart = CurTime()
        end
        local slideElapsed = CurTime() - timerSlideStart
        local target = slideElapsed > 1 and 0 or -ScrW() * 0.4
        posaddTimer = Lerp(FrameTime() * 5, posaddTimer, target)

        local remaining = math.max(0, (zb.ROUND_START + 240) - CurTime())
        local timeText = string.FormattedTime(remaining, "%02i:%02i") .. " До окончания раунда"
        draw.SimpleText(timeText, "ZB_HomicideMedium", ScrW() * 0.02 + posaddTimer, ScrH() * 0.95, Color(0,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        draw.SimpleText(timeText, "ZB_HomicideMedium", (ScrW() * 0.02) - 2 + posaddTimer, (ScrH() * 0.95) - 2, Color(255, 0, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    if zb.ROUND_START + 8.5 > CurTime() then
        if not ply:Alive() then return end
        local fade = math.Clamp(zb.ROUND_START + 8 - CurTime(), 0, 1)
        local team_ = ply:Team()
        draw.SimpleText("Hunter", "ZB_HomicideMediumLarge", ScrW() * 0.5, ScrH() * 0.1, Color(195, 117, 0, 255 * fade), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        local Rolename = teams[team_].name
        local ColorRole = teams[team_].color1
        ColorRole.a = 255 * fade
        draw.SimpleText("Ты " .. Rolename, "ZB_HomicideMediumLarge", ScrW() * 0.5, ScrH() * 0.5, ColorRole, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        local Objective = teams[team_].objective
        local ColorObj = teams[team_].color2
        ColorObj.a = 255 * fade
        draw.SimpleText(Objective, "ZB_HomicideMedium", ScrW() * 0.5, ScrH() * 0.9, ColorObj, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    if hg.PluvTown.Active and fade then
        surface.SetMaterial(hg.PluvTown.PluvMadness)
        surface.SetDrawColor(255, 255, 255, math.random(175, 255) * fade / 2)
        surface.DrawTexturedRect(ScrW() * 0.25, ScrH() * 0.44 - ScreenScale(15), ScrW() / 2, ScreenScale(30))

        draw.SimpleText("SOMEWHERE IN PLUVTOWN", "ZB_ScrappersLarge", ScrW() / 2, ScrH() * 0.44 - ScreenScale(2), Color(0, 0, 0, 255 * fade), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end

local CreateEndMenu
net.Receive("hns_roundend", function()
    roundEnding = true
    CreateEndMenu(net.ReadBool())
end)

local colGray = Color(85, 85, 85, 255)
local colRed = Color(130, 10, 10)
local colRedUp = Color(160, 30, 30)
local colBlue = Color(10, 10, 160)
local colBlueUp = Color(40, 40, 160)
local col = Color(255, 255, 255, 255)
local colSpect1 = Color(75, 75, 75, 255)
local colSpect2 = Color(255, 255, 255)
local colorBG = Color(55, 55, 55, 255)
local colorBGBlacky = Color(40, 40, 40, 255)
local blurMat = Material("pp/blurscreen")
local Dynamic = 0
BlurBackground = BlurBackground or hg.DrawBlur

if IsValid(hmcdEndMenu) then
    hmcdEndMenu:Remove()
    hmcdEndMenu = nil
end

CreateEndMenu = function(whowin)
    if IsValid(hmcdEndMenu) then
        hmcdEndMenu:Remove()
        hmcdEndMenu = nil
    end

    Dynamic = 0
    hmcdEndMenu = vgui.Create("ZFrame")
    surface.PlaySound( (whowin == 1) and "zbattle/criresp/failedSWAT.mp3" or "ambient/alarms/warningbell1.wav")
    local sizeX, sizeY = ScrW() / 2.5, ScrH() / 1.2
    local posX, posY = ScrW() / 1.3 - sizeX / 2, ScrH() / 2 - sizeY / 2
    hmcdEndMenu:SetPos(posX, posY)
    hmcdEndMenu:SetSize(sizeX, sizeY)
    hmcdEndMenu:MakePopup()
    hmcdEndMenu:SetKeyboardInputEnabled(false)
    hmcdEndMenu:ShowCloseButton(false)

    local closebutton = vgui.Create("DButton", hmcdEndMenu)
    closebutton:SetPos(5, 5)
    closebutton:SetSize(ScrW() / 20, ScrH() / 30)
    closebutton:SetText("")
    closebutton.DoClick = function()
        if IsValid(hmcdEndMenu) then
            hmcdEndMenu:Close()
            hmcdEndMenu = nil
        end
    end

    closebutton.Paint = function(self, w, h)
        surface.SetDrawColor(122, 122, 122, 255)
        surface.DrawOutlinedRect(0, 0, w, h, 2.5)
        surface.SetFont("ZB_InterfaceMedium")
        surface.SetTextColor(col.r, col.g, col.b, col.a)
        local lenghtX, lenghtY = surface.GetTextSize("Close")
        surface.SetTextPos(lenghtX - lenghtX / 1.1, 4)
        surface.DrawText("Close")
    end

    hmcdEndMenu.PaintOver = function(self, w, h)
        surface.SetFont("ZB_InterfaceMediumLarge")
        surface.SetTextColor(col.r, col.g, col.b, col.a)
        local lenghtX, lenghtY = surface.GetTextSize("Players:")
        surface.SetTextPos(w / 2 - lenghtX / 2, 20)
        surface.DrawText("Players:")
    end

    local DScrollPanel = vgui.Create("DScrollPanel", hmcdEndMenu)
    DScrollPanel:SetPos(10, 80)
    DScrollPanel:SetSize(sizeX - 20, sizeY - 90)

    for i, ply in player.Iterator() do
        if ply:Team() == TEAM_SPECTATOR then continue end
        local but = vgui.Create("DButton", DScrollPanel)
        but:SetSize(100, 50)
        but:Dock(TOP)
        but:DockMargin(8, 6, 8, -1)
        but:SetText("")
        but.Paint = function(self, w, h)
            local col1 = (ply:Alive() and colRed) or colGray
            local col2 = (ply:Alive() and colRedUp) or colSpect1
            surface.SetDrawColor(col1.r, col1.g, col1.b, col1.a)
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(col2.r, col2.g, col2.b, col2.a)
            surface.DrawRect(0, h / 2, w, h / 2)
            local col = ply:GetPlayerColor():ToColor()
            surface.SetFont("ZB_InterfaceMediumLarge")
            local lenghtX, lenghtY = surface.GetTextSize(ply:GetPlayerName() or "He quited...")
            surface.SetTextColor(0, 0, 0, 255)
            surface.SetTextPos(w / 2 + 1, h / 2 - lenghtY / 2 + 1)
            surface.DrawText(ply:GetPlayerName() or "Он ушел...")
            surface.SetTextColor(col.r, col.g, col.b, col.a)
            surface.SetTextPos(w / 2, h / 2 - lenghtY / 2)
            surface.DrawText(ply:GetPlayerName() or "Он ушел...")
            local col = colSpect2
            surface.SetFont("ZB_InterfaceMediumLarge")
            surface.SetTextColor(col.r, col.g, col.b, col.a)
            local lenghtX, lenghtY = surface.GetTextSize(ply:GetPlayerName() or "Он ушел...")
            surface.SetTextPos(15, h / 2 - lenghtY / 2)
            surface.DrawText(ply:Name() .. (ply:GetNetVar("handcuffed", false) and " - нейтрализован" or (not ply:Alive() and " - мертв") or " - жив"))
            surface.SetFont("ZB_InterfaceMediumLarge")
            surface.SetTextColor(col.r, col.g, col.b, col.a)
            local lenghtX, lenghtY = surface.GetTextSize(ply:Frags() or "Он ушел...")
            surface.SetTextPos(w - lenghtX - 15, h / 2 - lenghtY / 2)
            surface.DrawText(ply:Frags() or "Он ушел...")
        end

        function but:DoClick()
            if ply:IsBot() then
                chat.AddText(Color(255, 0, 0), "незя")
                return
            end

            gui.OpenURL("https://steamcommunity.com/profiles/" .. ply:SteamID64())
        end

        DScrollPanel:AddItem(but)
    end
    return true
end

function MODE:RoundStart()
    if IsValid(hmcdEndMenu) then
        hmcdEndMenu:Remove()
        hmcdEndMenu = nil
    end
    posadd = 0
    posaddTimer = 0
    timerSlideStart = 0
end